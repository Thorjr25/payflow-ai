'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Agent, 
  AgentStatus,
  Policy, 
  PaymentRequest, 
  Transaction, 
  AuditEvent, 
  AppNotification, 
  Environment,
  PolicyEvaluationResult
} from '@/types';
import { 
  INITIAL_AGENTS, 
  INITIAL_POLICIES, 
  INITIAL_PENDING_REQUESTS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_AUDIT_EVENTS 
} from '@/lib/demo/seed';
import { evaluatePaymentRequest } from '@/lib/policy/engine';
import { Language, TranslationKey, translations } from '@/lib/i18n/translations';

interface PayflowContextType {
  agents: Agent[];
  policies: Policy[];
  pendingRequests: PaymentRequest[];
  transactions: Transaction[];
  auditEvents: AuditEvent[];
  notifications: AppNotification[];
  emergencyStopActive: boolean;
  environment: Environment;
  language: Language;
  
  // Actions
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  setEnvironment: (env: Environment) => void;
  triggerEmergencyStop: () => void;
  resumeEmergencyStop: () => void;
  
  approvePaymentRequest: (requestId: string) => { success: boolean; message: string; transactionId?: string };
  rejectPaymentRequest: (requestId: string, reason?: string) => void;
  
  simulatePayment: (params: {
    agentId: string;
    service: string;
    amount: number;
    purpose: string;
  }) => PolicyEvaluationResult;

  createAgent: (agentData: Omit<Agent, 'id' | 'currentDailySpend' | 'currentMonthlySpend' | 'createdAt'>) => Agent;
  updateAgent: (id: string, updates: Partial<Agent>) => void;
  toggleAgentPause: (id: string) => void;
  deleteAgent: (id: string) => void;
  
  createPolicy: (policyData: Omit<Policy, 'id' | 'createdAt'>) => Policy;
  updatePolicy: (id: string, updates: Partial<Policy>) => void;
  
  createApprovalRule: (agentId: string, service: string, maxAmount: number) => void;
  addToast: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  toast: { message: string; type: string } | null;
  clearToast: () => void;
}

const PayflowContext = createContext<PayflowContextType | null>(null);

export const PayflowProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [policies, setPolicies] = useState<Policy[]>(INITIAL_POLICIES);
  const [pendingRequests, setPendingRequests] = useState<PaymentRequest[]>(INITIAL_PENDING_REQUESTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(INITIAL_AUDIT_EVENTS);
  const [emergencyStopActive, setEmergencyStopActive] = useState<boolean>(false);
  const [environment, setEnvState] = useState<Environment>('simulation');
  const [language, setLanguageState] = useState<Language>('en');
  const [toast, setToast] = useState<{ message: string; type: string } | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif-1',
      title: 'Payment Approval Required',
      message: 'Research Agent requested $0.72 for Premium Market Data',
      time: '2 min ago',
      read: false,
      type: 'approval',
      link: '/approvals'
    },
    {
      id: 'notif-2',
      title: 'Budget Utilization Warning',
      message: 'News Scanner has consumed 96.6% of its daily allocation',
      time: '12 min ago',
      read: false,
      type: 'warning',
      link: '/agents'
    }
  ]);

  // Load from localStorage on mount (hydration safe)
  useEffect(() => {
    try {
      const savedLang = localStorage.getItem('payflow_lang') as Language | null;
      if (savedLang === 'en' || savedLang === 'zh') {
        setLanguageState(savedLang);
      }

      const savedStop = localStorage.getItem('payflow_emergency_stop');
      if (savedStop !== null) setEmergencyStopActive(JSON.parse(savedStop));
      
      const savedAgents = localStorage.getItem('payflow_agents');
      if (savedAgents) setAgents(JSON.parse(savedAgents));

      const savedPolicies = localStorage.getItem('payflow_policies');
      if (savedPolicies) setPolicies(JSON.parse(savedPolicies));

      const savedPending = localStorage.getItem('payflow_pending');
      if (savedPending) setPendingRequests(JSON.parse(savedPending));

      const savedTx = localStorage.getItem('payflow_tx');
      if (savedTx) setTransactions(JSON.parse(savedTx));

      const savedAudit = localStorage.getItem('payflow_audit');
      if (savedAudit) setAuditEvents(JSON.parse(savedAudit));
    } catch (e) {
      console.warn('Could not read from localStorage', e);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('payflow_lang', lang);
    } catch (e) {
      // ignore
    }
  };

  const t = (key: TranslationKey): string => {
    return translations[language]?.[key] || translations['en']?.[key] || (key as string);
  };

  // Save changes to localStorage
  const persistState = (newAgents: Agent[], newPending: PaymentRequest[], newTx: Transaction[], newAudit: AuditEvent[]) => {
    try {
      localStorage.setItem('payflow_agents', JSON.stringify(newAgents));
      localStorage.setItem('payflow_pending', JSON.stringify(newPending));
      localStorage.setItem('payflow_tx', JSON.stringify(newTx));
      localStorage.setItem('payflow_audit', JSON.stringify(newAudit));
    } catch (e) {
      // ignore
    }
  };

  const addToast = (message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const clearToast = () => setToast(null);

  const setEnvironment = (env: Environment) => {
    if (env === 'production') {
      addToast('Production payments are not connected yet. Running in fail-closed Simulation Mode.', 'warning');
      return;
    }
    setEnvState(env);
  };

  const triggerEmergencyStop = () => {
    setEmergencyStopActive(true);
    localStorage.setItem('payflow_emergency_stop', JSON.stringify(true));
    
    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'EMERGENCY_STOP_ACTIVATED',
      message: 'GLOBAL EMERGENCY STOP ACTIVATED. All automated agent payment flows are blocked.',
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      result: 'BLOCKED'
    };
    
    const updatedAudit = [audit, ...auditEvents];
    setAuditEvents(updatedAudit);
    try {
      localStorage.setItem('payflow_audit', JSON.stringify(updatedAudit));
    } catch (e) {}

    addToast('GLOBAL EMERGENCY STOP ACTIVATED. All payments disabled.', 'error');
  };

  const resumeEmergencyStop = () => {
    setEmergencyStopActive(false);
    localStorage.setItem('payflow_emergency_stop', JSON.stringify(false));
    
    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'EMERGENCY_STOP_DISABLED',
      message: 'Global emergency stop deactivated. Normal policy evaluations restored.',
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      result: 'SUCCESS'
    };
    
    const updatedAudit = [audit, ...auditEvents];
    setAuditEvents(updatedAudit);
    try {
      localStorage.setItem('payflow_audit', JSON.stringify(updatedAudit));
    } catch (e) {}

    addToast('Emergency stop cleared. Payment authorizations re-enabled.', 'success');
  };

  const approvePaymentRequest = (requestId: string) => {
    const request = pendingRequests.find(r => r.id === requestId);
    if (!request) {
      return { success: false, message: 'Request not found' };
    }

    if (emergencyStopActive) {
      addToast('Cannot approve payment: Global Emergency Stop is active.', 'error');
      return { success: false, message: 'Emergency stop is active' };
    }

    const agent = agents.find(a => a.id === request.agentId);
    if (!agent) {
      return { success: false, message: 'Agent not found' };
    }

    // Fail closed if daily limit would be exceeded
    if (agent.currentDailySpend + request.amount > agent.dailyLimit) {
      addToast('Cannot approve: Approving this would exceed agent daily limit.', 'error');
      return { success: false, message: 'Daily limit exceeded' };
    }

    const txId = `SIM-TX-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    const completedTx: Transaction = {
      id: txId,
      paymentRequestId: request.id,
      agentId: agent.id,
      agentName: agent.name,
      service: request.service,
      amount: request.amount,
      currency: 'USD',
      decision: 'APPROVED',
      status: 'COMPLETED',
      environment: 'simulation',
      createdAt: request.createdAt,
      completedAt: now.toISOString(),
      policyId: request.policyId,
      purpose: request.purpose,
      riskLevel: request.riskLevel,
      reason: 'Approved manually by administrator in Pending Approvals.',
      paymentMethod: 'Configured Payment Profile (Simulation Rails)',
      auditTrail: [
        { time: request.createdAt.split('T')[1]?.substring(0, 8) || timeStr, action: `Request initiated by ${agent.name}`, status: 'passed', detail: `Amount: $${request.amount.toFixed(2)} for ${request.service}` },
        { time: timeStr, action: 'Policy threshold triggered', status: 'passed', detail: 'Human confirmation required and granted' },
        { time: timeStr, action: 'Payment authorized by Administrator', status: 'passed', detail: 'Manual approval confirmed via SecOps UI' },
        { time: timeStr, action: 'Settlement confirmed (Simulation Mode)', status: 'passed', detail: 'Mock authorization ledger confirmed' },
        { time: timeStr, action: 'Agent spend balance updated', status: 'passed', detail: `Daily spend now $${(agent.currentDailySpend + request.amount).toFixed(2)} / $${agent.dailyLimit.toFixed(2)}` }
      ]
    };

    // Update agent spend
    const updatedAgents = agents.map(a => {
      if (a.id === agent.id) {
        return {
          ...a,
          currentDailySpend: Number((a.currentDailySpend + request.amount).toFixed(2)),
          currentMonthlySpend: Number((a.currentMonthlySpend + request.amount).toFixed(2)),
          lastPaymentAt: 'Just now'
        };
      }
      return a;
    });

    const updatedPending = pendingRequests.filter(r => r.id !== requestId);
    const updatedTx = [completedTx, ...transactions];

    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      transactionId: txId,
      type: 'PAYMENT_APPROVED',
      message: `Administrator approved payment of $${request.amount.toFixed(2)} for ${agent.name} (${request.service})`,
      timestamp: now.toISOString(),
      actor: 'SecOps Administrator',
      target: txId,
      result: 'SUCCESS'
    };

    const updatedAudit = [audit, ...auditEvents];

    setAgents(updatedAgents);
    setPendingRequests(updatedPending);
    setTransactions(updatedTx);
    setAuditEvents(updatedAudit);
    persistState(updatedAgents, updatedPending, updatedTx, updatedAudit);

    addToast(`Payment of $${request.amount.toFixed(2)} approved. Transaction ${txId} generated.`, 'success');
    return { success: true, message: 'Payment approved', transactionId: txId };
  };

  const rejectPaymentRequest = (requestId: string, reason?: string) => {
    const request = pendingRequests.find(r => r.id === requestId);
    if (!request) return;

    const agent = agents.find(a => a.id === request.agentId);
    const updatedPending = pendingRequests.filter(r => r.id !== requestId);

    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'PAYMENT_REJECTED',
      message: `Administrator rejected payment of $${request.amount.toFixed(2)} for ${agent?.name || 'Agent'} (${request.service}). Reason: ${reason || 'Denied by policy reviewer'}.`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      target: request.id,
      result: 'BLOCKED'
    };

    const updatedAudit = [audit, ...auditEvents];

    setPendingRequests(updatedPending);
    setAuditEvents(updatedAudit);
    persistState(agents, updatedPending, transactions, updatedAudit);

    addToast(`Payment request for ${request.service} rejected.`, 'info');
  };

  const simulatePayment = (params: {
    agentId: string;
    service: string;
    amount: number;
    purpose: string;
  }): PolicyEvaluationResult => {
    const agent = agents.find(a => a.id === params.agentId);
    const policy = policies.find(p => p.id === (agent?.policyId || 'policy-research')) || policies[0];

    if (!agent) {
      const fallbackResult: PolicyEvaluationResult = {
        decision: 'BLOCKED',
        reason: 'Unknown agent. Authorization fails closed.',
        riskLevel: 'CRITICAL',
        checks: [{ name: 'Agent Check', passed: false, code: 'AGENT_AUTH', details: 'Agent ID invalid' }],
        budgetImpact: { currentSpend: 0, limit: 0, amount: params.amount, newSpend: 0, remainingBefore: 0, remainingAfter: 0, percentUsedBefore: 0, percentUsedAfter: 0 },
        requiresHumanApproval: false,
        policyId: 'none',
        timestamp: new Date().toISOString()
      };
      return fallbackResult;
    }

    const evaluation = evaluatePaymentRequest({
      agent,
      policy,
      service: params.service,
      amount: params.amount,
      purpose: params.purpose,
      emergencyStopActive
    });

    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    const reqId = `req-sim-${Date.now()}`;

    if (evaluation.decision === 'APPROVED') {
      const txId = `SIM-TX-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      const newTx: Transaction = {
        id: txId,
        paymentRequestId: reqId,
        agentId: agent.id,
        agentName: agent.name,
        service: params.service,
        amount: params.amount,
        currency: 'USD',
        decision: 'APPROVED',
        status: 'COMPLETED',
        environment: 'simulation',
        createdAt: now.toISOString(),
        completedAt: now.toISOString(),
        policyId: policy.id,
        purpose: params.purpose,
        riskLevel: evaluation.riskLevel,
        reason: evaluation.reason,
        paymentMethod: 'Configured Payment Profile (Simulation Rails)',
        auditTrail: [
          { time: timeStr, action: `Request initiated by ${agent.name}`, status: 'passed', detail: `Amount: $${params.amount.toFixed(2)} for ${params.service}` },
          { time: timeStr, action: `Evaluated policy: ${policy.name}`, status: 'passed', detail: 'All policy checks satisfied autonomously' },
          { time: timeStr, action: 'Payment authorized & executed', status: 'passed', detail: 'Zero human intervention required' },
          { time: timeStr, action: 'Transaction logged', status: 'passed', detail: 'Audit ledger entry written' }
        ]
      };

      const updatedAgents = agents.map(a => {
        if (a.id === agent.id) {
          return {
            ...a,
            currentDailySpend: Number((a.currentDailySpend + params.amount).toFixed(2)),
            currentMonthlySpend: Number((a.currentMonthlySpend + params.amount).toFixed(2)),
            lastPaymentAt: 'Just now'
          };
        }
        return a;
      });

      const updatedTx = [newTx, ...transactions];
      const audit: AuditEvent = {
        id: `audit-${Date.now()}`,
        transactionId: txId,
        type: 'PAYMENT_EVALUATED',
        message: `Autonomous approval: ${agent.name} paid $${params.amount.toFixed(2)} to ${params.service}`,
        timestamp: now.toISOString(),
        actor: 'PAYFLOW Engine',
        target: txId,
        result: 'SUCCESS'
      };
      const updatedAudit = [audit, ...auditEvents];

      setAgents(updatedAgents);
      setTransactions(updatedTx);
      setAuditEvents(updatedAudit);
      persistState(updatedAgents, pendingRequests, updatedTx, updatedAudit);

      addToast(`Payment of $${params.amount.toFixed(2)} approved autonomously (${txId})`, 'success');
    } else if (evaluation.decision === 'PENDING_APPROVAL') {
      const newPendingReq: PaymentRequest = {
        id: reqId,
        agentId: agent.id,
        service: params.service,
        amount: params.amount,
        currency: 'USD',
        purpose: params.purpose,
        status: 'PENDING_APPROVAL',
        riskLevel: evaluation.riskLevel,
        decisionReason: evaluation.reason,
        createdAt: now.toISOString(),
        policyId: policy.id,
        environment: 'simulation',
        evaluation
      };

      const updatedPending = [newPendingReq, ...pendingRequests];
      const audit: AuditEvent = {
        id: `audit-${Date.now()}`,
        type: 'PAYMENT_REQUESTED',
        message: `${agent.name} requested $${params.amount.toFixed(2)} for ${params.service}. Exceeds threshold ($${policy.approvalThreshold.toFixed(2)}). Routed for review.`,
        timestamp: now.toISOString(),
        actor: agent.name,
        target: reqId,
        result: 'PENDING'
      };
      const updatedAudit = [audit, ...auditEvents];

      setPendingRequests(updatedPending);
      setAuditEvents(updatedAudit);
      persistState(agents, updatedPending, transactions, updatedAudit);

      addToast(`Amount $${params.amount.toFixed(2)} routed to Pending Approvals (Review Required)`, 'warning');
    } else {
      // BLOCKED
      const txId = `SIM-TX-BLK-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const blockedTx: Transaction = {
        id: txId,
        paymentRequestId: reqId,
        agentId: agent.id,
        agentName: agent.name,
        service: params.service,
        amount: params.amount,
        currency: 'USD',
        decision: 'BLOCKED',
        status: 'BLOCKED',
        environment: 'simulation',
        createdAt: now.toISOString(),
        policyId: policy.id,
        purpose: params.purpose,
        riskLevel: evaluation.riskLevel,
        reason: evaluation.reason,
        paymentMethod: 'None (Blocked)',
        auditTrail: [
          { time: timeStr, action: `Request initiated by ${agent.name}`, status: 'passed', detail: `Amount: $${params.amount.toFixed(2)} for ${params.service}` },
          { time: timeStr, action: 'Policy verification check', status: 'failed', detail: evaluation.reason },
          { time: timeStr, action: 'Transaction blocked', status: 'failed', detail: 'Zero funds disbursed. System failed closed.' }
        ]
      };

      const updatedTx = [blockedTx, ...transactions];
      const audit: AuditEvent = {
        id: `audit-${Date.now()}`,
        transactionId: txId,
        type: 'PAYMENT_BLOCKED',
        message: `BLOCKED payment of $${params.amount.toFixed(2)} from ${agent.name} for ${params.service}: ${evaluation.reason}`,
        timestamp: now.toISOString(),
        actor: 'PAYFLOW Engine',
        target: agent.id,
        result: 'BLOCKED'
      };
      const updatedAudit = [audit, ...auditEvents];

      setTransactions(updatedTx);
      setAuditEvents(updatedAudit);
      persistState(agents, pendingRequests, updatedTx, updatedAudit);

      addToast(`Payment BLOCKED: ${evaluation.reason}`, 'error');
    }

    return evaluation;
  };

  const createAgent = (agentData: Omit<Agent, 'id' | 'currentDailySpend' | 'currentMonthlySpend' | 'createdAt'>): Agent => {
    const newAgent: Agent = {
      ...agentData,
      id: `agent-${Date.now().toString(36)}`,
      currentDailySpend: 0,
      currentMonthlySpend: 0,
      createdAt: new Date().toISOString(),
      lastPaymentAt: 'Never'
    };

    const updated = [...agents, newAgent];
    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'AGENT_CREATED',
      message: `Created new agent: "${newAgent.name}" with $${newAgent.dailyLimit.toFixed(2)} daily ceiling.`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      target: newAgent.id,
      result: 'SUCCESS'
    };
    const updatedAudit = [audit, ...auditEvents];

    setAgents(updated);
    setAuditEvents(updatedAudit);
    persistState(updated, pendingRequests, transactions, updatedAudit);
    addToast(`Agent "${newAgent.name}" created successfully.`, 'success');
    return newAgent;
  };

  const updateAgent = (id: string, updates: Partial<Agent>) => {
    const updated = agents.map(a => a.id === id ? { ...a, ...updates } : a);
    setAgents(updated);
    persistState(updated, pendingRequests, transactions, auditEvents);
    addToast('Agent settings updated.', 'success');
  };

  const toggleAgentPause = (id: string) => {
    const target = agents.find(a => a.id === id);
    if (!target) return;
    const newStatus: AgentStatus = target.status === 'active' ? 'paused' : 'active';
    const updated: Agent[] = agents.map(a => a.id === id ? { ...a, status: newStatus } : a);

    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: newStatus === 'paused' ? 'AGENT_PAUSED' : 'AGENT_RESUMED',
      message: `Agent "${target.name}" status changed to ${newStatus.toUpperCase()}.`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      target: target.id,
      result: 'SUCCESS'
    };
    const updatedAudit = [audit, ...auditEvents];

    setAgents(updated);
    setAuditEvents(updatedAudit);
    persistState(updated, pendingRequests, transactions, updatedAudit);
    addToast(`Agent "${target.name}" is now ${newStatus}.`, 'info');
  };

  const deleteAgent = (id: string) => {
    const target = agents.find(a => a.id === id);
    if (!target) return;
    const updated = agents.filter(a => a.id !== id);
    setAgents(updated);
    persistState(updated, pendingRequests, transactions, auditEvents);
    addToast(`Agent "${target.name}" deleted.`, 'info');
  };

  const createPolicy = (policyData: Omit<Policy, 'id' | 'createdAt'>): Policy => {
    const newPolicy: Policy = {
      ...policyData,
      id: `policy-${Date.now().toString(36)}`,
      createdAt: new Date().toISOString()
    };
    const updated = [...policies, newPolicy];
    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'POLICY_CREATED',
      message: `Committed new payment policy: "${newPolicy.name}".`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      target: newPolicy.id,
      result: 'SUCCESS'
    };
    const updatedAudit = [audit, ...auditEvents];
    setPolicies(updated);
    setAuditEvents(updatedAudit);
    try {
      localStorage.setItem('payflow_policies', JSON.stringify(updated));
      localStorage.setItem('payflow_audit', JSON.stringify(updatedAudit));
    } catch (e) {}
    addToast(`Policy "${newPolicy.name}" created.`, 'success');
    return newPolicy;
  };

  const updatePolicy = (id: string, updates: Partial<Policy>) => {
    const updated = policies.map(p => p.id === id ? { ...p, ...updates } : p);
    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'POLICY_UPDATED',
      message: `Updated policy permissions for policy ID: ${id}.`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      target: id,
      result: 'SUCCESS'
    };
    const updatedAudit = [audit, ...auditEvents];
    setPolicies(updated);
    setAuditEvents(updatedAudit);
    try {
      localStorage.setItem('payflow_policies', JSON.stringify(updated));
      localStorage.setItem('payflow_audit', JSON.stringify(updatedAudit));
    } catch (e) {}
    addToast('Policy updated successfully.', 'success');
  };

  const createApprovalRule = (agentId: string, service: string, maxAmount: number) => {
    const agent = agents.find(a => a.id === agentId);
    const policy = policies.find(p => p.id === agent?.policyId);
    if (policy) {
      const allowed = Array.from(new Set([...policy.allowedServices, service]));
      const updatedThreshold = Math.max(policy.approvalThreshold, maxAmount);
      updatePolicy(policy.id, {
        allowedServices: allowed,
        approvalThreshold: updatedThreshold
      });
    }

    const audit: AuditEvent = {
      id: `audit-${Date.now()}`,
      type: 'APPROVAL_RULE_CREATED',
      message: `Created permanent approval rule: Always allow ${service} up to $${maxAmount.toFixed(2)} for ${agent?.name || 'Agent'}.`,
      timestamp: new Date().toISOString(),
      actor: 'SecOps Administrator',
      result: 'SUCCESS'
    };
    setAuditEvents([audit, ...auditEvents]);
    addToast(`Rule created: Always allow ${service} under $${maxAmount.toFixed(2)}.`, 'success');
  };

  return (
    <PayflowContext.Provider
      value={{
        agents,
        policies,
        pendingRequests,
        transactions,
        auditEvents,
        notifications,
        emergencyStopActive,
        environment,
        language,
        setLanguage,
        t,
        setEnvironment,
        triggerEmergencyStop,
        resumeEmergencyStop,
        approvePaymentRequest,
        rejectPaymentRequest,
        simulatePayment,
        createAgent,
        updateAgent,
        toggleAgentPause,
        deleteAgent,
        createPolicy,
        updatePolicy,
        createApprovalRule,
        addToast,
        toast,
        clearToast
      }}
    >
      {children}
    </PayflowContext.Provider>
  );
};

export const usePayflow = () => {
  const context = useContext(PayflowContext);
  if (!context) {
    throw new Error('usePayflow must be used within a PayflowProvider');
  }
  return context;
};
