'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  PayflowLogo, 
  Button, 
  SimulationBadge 
} from '@/components/ui';
import { usePayflow } from '@/context/PayflowContext';
import { 
  LayoutDashboard, 
  Bot, 
  ShieldCheck, 
  Inbox, 
  ReceiptText, 
  BarChart3, 
  ShieldAlert, 
  Sliders, 
  AlertOctagon, 
  Menu, 
  X,
  PlayCircle,
  HelpCircle
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';

export const AppShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const pathname = usePathname();
  const { 
    emergencyStopActive, 
    pendingRequests, 
    environment, 
    setEnvironment, 
    resumeEmergencyStop,
    language,
    setLanguage,
    t,
    toast,
    clearToast
  } = usePayflow();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [prodModalOpen, setProdModalOpen] = useState(false);
  const [simDrawerOpen, setSimDrawerOpen] = useState(false);

  const pendingCount = pendingRequests.length;

  const navItems = [
    { href: '/dashboard', label: t('nav.overview'), icon: LayoutDashboard },
    { href: '/agents', label: t('nav.agents'), icon: Bot },
    { href: '/policies', label: t('nav.policies'), icon: ShieldCheck },
    { href: '/approvals', label: t('nav.approvals'), icon: Inbox, badge: pendingCount > 0 ? pendingCount : undefined },
    { href: '/transactions', label: t('nav.transactions'), icon: ReceiptText },
    { href: '/analytics', label: t('nav.analytics'), icon: BarChart3 },
  ];

  const secondaryNav = [
    { href: '/security', label: t('nav.security'), icon: ShieldAlert },
    { href: '/integrations', label: t('nav.integrations'), icon: Sliders },
  ];

  return (
    <div className="min-h-screen bg-black/40 text-white flex flex-col md:flex-row relative z-10">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-md bg-surface-3 border border-white/20 shadow-2xl animate-in slide-in-from-bottom-3 duration-200">
          <div className="w-2 h-2 rounded-full bg-white animate-ping" />
          <span className="text-xs text-white font-medium">{toast.message}</span>
          <button 
            onClick={clearToast}
            className="text-neutral-400 hover:text-white ml-2 text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* Emergency Stop Global Persistent Banner */}
      {emergencyStopActive && (
        <div className="fixed top-0 inset-x-0 z-50 bg-red-950/90 border-b border-red-700/60 px-4 py-2.5 flex items-center justify-between text-xs backdrop-blur-md">
          <div className="flex items-center gap-2.5 text-red-200 font-medium">
            <AlertOctagon className="w-4 h-4 text-red-400 animate-pulse" />
            <span>PAYMENTS DISABLED — Global payment emergency stop is active. 100% of agent requests fail closed.</span>
          </div>
          <button 
            onClick={resumeEmergencyStop}
            className="px-2.5 py-1 rounded text-xs font-semibold bg-white text-black hover:bg-neutral-200 transition-colors shadow-sm"
          >
            Resume Payments
          </button>
        </div>
      )}

      {/* Mobile Top Header */}
      <div className={`md:hidden flex items-center justify-between px-4 py-3 bg-surface-1 border-b border-white/10 ${emergencyStopActive ? 'mt-11' : ''}`}>
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <PayflowLogo size={20} />
          <span className="font-semibold text-xs tracking-wider">PAYFLOW</span>
        </Link>
        <div className="flex items-center gap-2">
          <SimulationBadge />
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 rounded text-neutral-400 hover:text-white hover:bg-white/10"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Desktop Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-surface-1/80 backdrop-blur-xl border-r border-white/10 flex flex-col justify-between transition-transform duration-200
        md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
        ${emergencyStopActive ? 'pt-11 md:pt-11' : ''}
      `}>
        {/* Top Branding */}
        <div>
          <div className="p-5 border-b border-white/10 flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center gap-2.5 group">
              <PayflowLogo size={22} className="group-hover:scale-105 transition-transform" />
              <div>
                <div className="font-bold text-xs tracking-widest text-white">PAYFLOW</div>
                <div className="text-[10px] text-neutral-500 font-mono">Payment Control Plane</div>
              </div>
            </Link>
            <div className="hidden md:block">
              <SimulationBadge />
            </div>
          </div>

          {/* Primary Navigation */}
          <nav className="p-3 space-y-1">
            <div className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-neutral-500">
              {t('nav.operations')}
            </div>
            {navItems.map((item) => {
              const active = pathname === item.href || (item.href !== '/dashboard' && pathname?.startsWith(item.href));
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`
                    flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-all
                    ${active 
                      ? 'bg-white/[0.08] text-white border border-white/10 shadow-sm' 
                      : 'text-neutral-400 hover:text-white hover:bg-white/[0.03] border border-transparent'}
                  `}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-neutral-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono">
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}

            <div className="pt-4 px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-neutral-500">
              {t('nav.controlSystem')}
            </div>
            {secondaryNav.map((item) => {
              const active = pathname === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`
                    flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-all
                    ${active 
                      ? 'bg-white/[0.08] text-white border border-white/10 shadow-sm' 
                      : 'text-neutral-400 hover:text-white hover:bg-white/[0.03] border border-transparent'}
                  `}
                >
                  <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-neutral-500'}`} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar Info & Simulator Quick-Trigger */}
        <div className="p-3 border-t border-white/10 space-y-2 bg-surface-2/40">
          {/* Quick Scenario Runner Trigger */}
          <Link
            href="/dashboard?tab=simulate"
            className="w-full flex items-center justify-between px-3 py-2 rounded-md bg-white/[0.04] border border-white/10 hover:border-white/20 text-xs text-neutral-300 hover:text-white transition-all group"
          >
            <div className="flex items-center gap-2">
              <PlayCircle className="w-3.5 h-3.5 text-neutral-400 group-hover:text-white transition-colors" />
              <span>{t('nav.simulatePayment')}</span>
            </div>
            <span className="text-[10px] font-mono text-neutral-500">{t('nav.runner')}</span>
          </Link>

          {/* Quick Language Switcher */}
          <div className="flex items-center justify-between p-2 rounded bg-black/40 border border-white/5 text-[11px]">
            <span className="text-neutral-400 flex items-center gap-1.5">
              <span>🌐</span>
              <span>{language === 'zh' ? '语言' : 'Language'}:</span>
            </span>
            <div className="flex items-center gap-1 bg-surface-1 p-0.5 rounded border border-white/10">
              <button 
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                  language === 'en' 
                    ? 'bg-white text-black font-semibold shadow-sm' 
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Switch to English"
              >
                EN
              </button>
              <button 
                onClick={() => setLanguage('zh')}
                className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                  language === 'zh' 
                    ? 'bg-white text-black font-semibold shadow-sm' 
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="切换为中文 (Chinese)"
              >
                中文
              </button>
            </div>
          </div>

          {/* Environment Switcher */}
          <div className="flex items-center justify-between p-2 rounded bg-black/40 border border-white/5 text-[11px]">
            <span className="text-neutral-400">{t('nav.environment')}</span>
            <div className="flex items-center gap-1 bg-surface-1 p-0.5 rounded border border-white/10">
              <button 
                className="px-2 py-0.5 rounded text-[10px] font-medium bg-white text-black font-semibold"
                title="Simulation Rails active"
              >
                {t('nav.sim')}
              </button>
              <button 
                onClick={() => setProdModalOpen(true)}
                className="px-2 py-0.5 rounded text-[10px] font-medium text-neutral-500 hover:text-neutral-300"
                title="Production not connected"
              >
                {t('nav.prod')}
              </button>
            </div>
          </div>

          {/* SecOps User Profile */}
          <div className="flex items-center gap-2.5 px-2 py-1.5">
            <div className="w-6 h-6 rounded-full bg-gradient-to-b from-neutral-600 to-neutral-800 border border-white/20 flex items-center justify-center text-[10px] font-mono font-bold text-white">
              SO
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-medium text-white truncate">secops@payflow.ai</div>
              <div className="text-[10px] text-neutral-500 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                {t('nav.failClosedPolicy')}
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 md:ml-64 flex flex-col min-h-screen ${emergencyStopActive ? 'pt-11 md:pt-11' : ''}`}>
        {children}
      </main>

      {/* Production Modal Informational Dialog */}
      <Modal
        isOpen={prodModalOpen}
        onClose={() => setProdModalOpen(false)}
        title="Production Environment Status"
        subtitle="Hardware & Custodial Security Gate"
      >
        <div className="space-y-4 text-xs text-neutral-300 leading-relaxed">
          <div className="p-3 rounded bg-white/[0.03] border border-white/10 font-mono text-[11px] text-neutral-300 space-y-1">
            <div className="text-white font-semibold">Production Status: DISCONNECTED</div>
            <div>Provider: X402 Native Payment Rail (Pending Configuration)</div>
            <div>Custodial Boundary: Server-Side Enclave Only</div>
          </div>
          <p>
            PAYFLOW strictly adheres to the <span className="text-white font-semibold">Fail-Closed Guarantee</span>: 
            Production financial rails cannot be simulated. When live merchant or on-chain settlement credentials are not connected via private vault, production routing is completely disabled.
          </p>
          <p className="text-neutral-400 text-[11px]">
            All current interactions will execute on our isolated deterministic simulation engine with zero real financial exposure.
          </p>
          <div className="pt-2 flex justify-end">
            <Button variant="primary" size="md" onClick={() => setProdModalOpen(false)}>
              Acknowledge & Return to Simulation
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
