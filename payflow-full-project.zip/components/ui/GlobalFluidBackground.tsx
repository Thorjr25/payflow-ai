'use client';

import React from 'react';
import { FluidClouds } from '@/components/ui/FluidClouds';

export const GlobalFluidBackground: React.FC = () => {
  return (
    <>
      {/* 
        ========================================================================
        LAYER 0: FIXED ANIMATED FLUID/CLOUD EFFECT (WebGL Domain-Warped Clouds)
        Slow, organic movement to completely avoid motion sickness.
        Fixed across the entire viewport so it remains stationary while scrolling.
        ========================================================================
      */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <FluidClouds className="w-full h-full object-cover" />
      </div>

      {/* 
        ========================================================================
        LAYER 1: CRYSTAL FROSTED GLASS & CONTRAST SCRIM OVERLAY
        Balanced transparency so vibrant clouds are richly visible across
        all pages while maintaining strict text readability and contrast.
        ========================================================================
      */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 bg-black/15 backdrop-blur-[6px] [background-image:radial-gradient(ellipse_80%_60%_at_50%_30%,rgba(0,0,0,0.05)_0%,rgba(0,0,0,0.55)_100%)]" 
        aria-hidden="true"
      />
    </>
  );
};
