'use client';

import React, { useEffect, useRef } from 'react';

interface FluidCloudsProps {
  className?: string;
}

export const FluidClouds: React.FC<FluidCloudsProps> = ({ className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Try WebGL first with direct screen rendering
    const gl = canvas.getContext('webgl', { alpha: false, antialias: true, powerPreference: 'high-performance' });
    let animationFrameId: number;

    if (gl) {
      const vsSource = `
        attribute vec2 position;
        void main() {
          gl_Position = vec4(position, 0.0, 1.0);
        }
      `;

      // Highly vibrant, ultra-dense volumetric fluid cloud shader
      const fsSource = `
        precision highp float;
        uniform float uTime;
        uniform vec2 uResolution;

        vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
        vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
        vec3 permute(vec3 x) { return mod289(((x*34.0)+1.0)*x); }

        float snoise(vec2 v) {
          const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
          vec2 i  = floor(v + dot(v, C.yy) );
          vec2 x0 = v -   i + dot(i, C.xx);
          vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
          vec4 x12 = x0.xyxy + C.xxzz;
          x12.xy -= i1;
          i = mod289(i);
          vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 )) + i.x + vec3(0.0, i1.x, 1.0 ));
          vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
          m = m*m ;
          m = m*m ;
          vec3 x = 2.0 * fract(p * C.www) - 1.0;
          vec3 h = abs(x) - 0.5;
          vec3 ox = floor(x + 0.5);
          vec3 a0 = x - ox;
          m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
          vec3 g;
          g.x  = a0.x  * x0.x  + h.x  * x0.y;
          g.yz = a0.yz * x12.xz + h.yz * x12.yw;
          return 130.0 * dot(m, g);
        }

        float fbm(vec2 p) {
          float v = 0.0;
          float a = 0.55;
          for (int i = 0; i < 4; i++) {
            v += a * snoise(p);
            p = p * 2.1 + vec2(100.0);
            a *= 0.48;
          }
          return v;
        }

        void main() {
          vec2 st = gl_FragCoord.xy / uResolution.xy;
          st.x *= uResolution.x / uResolution.y;

          // Slow organic fluid evolution
          float t = uTime * 0.08;

          vec2 q = vec2(fbm(st + vec2(t * 0.3, t * 0.2)), fbm(st + vec2(t * -0.25, t * 0.35)));
          vec2 r = vec2(fbm(st + 2.5 * q + vec2(t * 0.2, -t * 0.15)), fbm(st + 2.5 * q + vec2(-t * 0.18, t * 0.22)));

          float f = fbm(st + 3.0 * r);

          // Vivid, brilliant spectrum of fluid cloud colors
          vec3 cViolet = vec3(0.65, 0.15, 0.95);  // Vivid Purple/Violet
          vec3 cCyan   = vec3(0.05, 0.85, 0.98);  // Vibrant Cyan
          vec3 cAmber  = vec3(1.00, 0.60, 0.10);  // Solar Amber / Gold
          vec3 cRose   = vec3(0.98, 0.20, 0.55);  // Bright Sunset Magenta
          vec3 cNavy   = vec3(0.06, 0.09, 0.28);  // Deep Nebula Blue

          // Blend fluid dynamics
          vec3 color = mix(cNavy, cViolet, clamp(f * 1.8, 0.0, 1.0));
          color = mix(color, cCyan, clamp(length(q) * 1.2, 0.0, 1.0));
          color = mix(color, cRose, clamp(length(r.x) * 1.4, 0.0, 1.0));
          color = mix(color, cAmber, clamp(f * f * 2.5, 0.0, 1.0));

          // Boost brightness and cloud billows
          color = pow(color, vec3(0.85)) * 1.45;

          gl_FragColor = vec4(color, 1.0);
        }
      `;

      const createShader = (type: number, src: string) => {
        const s = gl.createShader(type);
        if (!s) return null;
        gl.shaderSource(s, src);
        gl.compileShader(s);
        return s;
      };

      const vs = createShader(gl.VERTEX_SHADER, vsSource);
      const fs = createShader(gl.FRAGMENT_SHADER, fsSource);
      const prog = gl.createProgram();

      if (vs && fs && prog) {
        gl.attachShader(prog, vs);
        gl.attachShader(prog, fs);
        gl.linkProgram(prog);
        gl.useProgram(prog);

        const buf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(
          gl.ARRAY_BUFFER,
          new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
          gl.STATIC_DRAW
        );

        const pos = gl.getAttribLocation(prog, 'position');
        gl.enableVertexAttribArray(pos);
        gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0);

        const uTime = gl.getUniformLocation(prog, 'uTime');
        const uRes = gl.getUniformLocation(prog, 'uResolution');

        const onResize = () => {
          if (!canvas) return;
          canvas.width = window.innerWidth;
          canvas.height = window.innerHeight;
          gl.viewport(0, 0, canvas.width, canvas.height);
          if (uRes) gl.uniform2f(uRes, canvas.width, canvas.height);
        };

        onResize();
        window.addEventListener('resize', onResize);

        const start = performance.now();
        const render = () => {
          const now = (performance.now() - start) * 0.001;
          if (uTime) gl.uniform1f(uTime, now);
          gl.drawArrays(gl.TRIANGLES, 0, 6);
          animationFrameId = requestAnimationFrame(render);
        };

        render();

        return () => {
          window.removeEventListener('resize', onResize);
          cancelAnimationFrame(animationFrameId);
        };
      }
    }

    // High-contrast, dense 2D Canvas fallback
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const onResize2D = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize2D);

    let t = 0;
    const render2D = () => {
      t += 0.007;
      ctx.fillStyle = '#060814';
      ctx.fillRect(0, 0, width, height);

      ctx.save();
      ctx.globalCompositeOperation = 'screen';

      const clouds = [
        { x: width * 0.35 + Math.sin(t * 0.8) * 120, y: height * 0.35 + Math.cos(t * 0.6) * 90, r: width * 0.55, col: 'rgba(168, 85, 247, 0.75)' },
        { x: width * 0.65 + Math.cos(t * 0.7) * 130, y: height * 0.45 + Math.sin(t * 0.9) * 110, r: width * 0.60, col: 'rgba(6, 182, 212, 0.75)' },
        { x: width * 0.50 + Math.sin(t * 1.1) * 100, y: height * 0.60 + Math.cos(t * 0.8) * 80, r: width * 0.50, col: 'rgba(244, 63, 94, 0.70)' },
        { x: width * 0.20 + Math.cos(t * 0.5) * 90, y: height * 0.55 + Math.sin(t * 0.7) * 70, r: width * 0.45, col: 'rgba(245, 158, 11, 0.65)' },
      ];

      for (const c of clouds) {
        const grad = ctx.createRadialGradient(c.x, c.y, 10, c.x, c.y, c.r);
        grad.addColorStop(0, c.col);
        grad.addColorStop(0.5, c.col.replace(/[\d\.]+\)$/, '0.35)'));
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      animationFrameId = requestAnimationFrame(render2D);
    };

    render2D();

    return () => {
      window.removeEventListener('resize', onResize2D);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className={`w-full h-full pointer-events-none select-none block ${className}`}
    />
  );
};
