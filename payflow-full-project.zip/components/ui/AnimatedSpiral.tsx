'use client';

import React, { useEffect, useRef } from 'react';

interface SpiralCanvasProps {
  className?: string;
  speed?: number;
}

export const AnimatedSpiral: React.FC<SpiralCanvasProps> = ({ 
  className = '',
  speed = 0.0025
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;

    const resize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    let angle = 0;
    const arms = 6;
    const pointsPerArm = 260; // Denser particles for rich clouds

    const render = () => {
      angle += speed;
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height * 0.42; // slightly elevated center for hero harmony
      const maxRadius = Math.max(width, height) * 0.65;

      ctx.save();
      // High-luminous blending for volumetric color cloud appearance
      ctx.globalCompositeOperation = 'screen';

      // 1. Soft atmospheric cloud halos rotating in opposing cadence
      for (let c = 0; c < 4; c++) {
        const cAngle = angle * (c % 2 === 0 ? 1 : -0.7) + (c * Math.PI) / 2;
        const cDist = 80 + c * 45;
        const cloudX = cx + Math.cos(cAngle) * cDist;
        const cloudY = cy + Math.sin(cAngle) * cDist;
        const cloudR = 180 + c * 70;

        const cloudGrad = ctx.createRadialGradient(cloudX, cloudY, 10, cloudX, cloudY, cloudR);
        const cloudHue = (angle * 35 + c * 90) % 360;
        cloudGrad.addColorStop(0, `hsla(${cloudHue}, 90%, 65%, 0.28)`);
        cloudGrad.addColorStop(0.5, `hsla(${(cloudHue + 40) % 360}, 85%, 55%, 0.14)`);
        cloudGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = cloudGrad;
        ctx.beginPath();
        ctx.arc(cloudX, cloudY, cloudR, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. Thick, volumetric spiral arms of glowing cosmic clouds
      for (let arm = 0; arm < arms; arm++) {
        const armOffset = (arm * (Math.PI * 2)) / arms;

        for (let i = 0; i < pointsPerArm; i++) {
          const progress = i / pointsPerArm;
          // Logarithmic spiral expansion
          const r = Math.pow(progress, 1.25) * maxRadius;
          const theta = armOffset + angle * 1.8 + progress * Math.PI * 5.2;

          const x = cx + Math.cos(theta) * r;
          const y = cy + Math.sin(theta) * r;

          // Shifting rainbow spectral hue
          const hue = (angle * 45 + progress * 320 + arm * 60) % 360;
          
          // Thicker cloud sizing & dense particle glow
          const cloudSpread = 4.5 + progress * 14.0;
          const alpha = (1 - progress * 0.35) * (0.28 + 0.18 * Math.sin(progress * Math.PI * 2 + angle * 2.5));

          ctx.beginPath();
          ctx.arc(x, y, cloudSpread, 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${hue}, 92%, 62%, ${alpha})`;
          ctx.shadowBlur = 24 + progress * 24;
          ctx.shadowColor = `hsla(${hue}, 95%, 62%, 0.85)`;
          ctx.fill();

          // Sub-particle puff for dense fog texture
          if (i % 2 === 0) {
            const puffAngle = theta + (i % 3) * 0.3;
            const puffDist = (Math.sin(i + angle * 4) * 16);
            ctx.beginPath();
            ctx.arc(x + Math.cos(puffAngle) * puffDist, y + Math.sin(puffAngle) * puffDist, cloudSpread * 0.75, 0, Math.PI * 2);
            ctx.fillStyle = `hsla(${(hue + 25) % 360}, 95%, 68%, ${alpha * 0.55})`;
            ctx.fill();
          }
        }
      }

      // 3. Central blazing rainbow sun / pulsar core
      const corePulse = 26 + Math.sin(angle * 3.5) * 6;
      const coreGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, corePulse * 3.2);
      coreGrad.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
      coreGrad.addColorStop(0.18, 'rgba(255, 235, 140, 0.85)');
      coreGrad.addColorStop(0.42, 'rgba(255, 100, 180, 0.55)');
      coreGrad.addColorStop(0.72, 'rgba(120, 90, 255, 0.30)');
      coreGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.beginPath();
      ctx.arc(cx, cy, corePulse * 3.2, 0, Math.PI * 2);
      ctx.fillStyle = coreGrad;
      ctx.shadowBlur = 45;
      ctx.shadowColor = 'rgba(255, 210, 120, 0.9)';
      ctx.fill();

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [speed]);

  return (
    <canvas 
      ref={canvasRef} 
      className={`w-full h-full pointer-events-none select-none ${className}`}
    />
  );
};
