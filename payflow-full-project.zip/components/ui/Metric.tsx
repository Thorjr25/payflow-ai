import React from 'react';
import { Button } from '@/components/ui';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface MetricProps {
  label: string;
  value: string | number;
  sublabel?: string;
  trend?: {
    value: string;
    direction: 'up' | 'down' | 'neutral';
    label?: string;
  };
  highlight?: boolean;
}

export const Metric: React.FC<MetricProps> = ({
  label,
  value,
  sublabel,
  trend,
  highlight = false,
}) => {
  return (
    <div className={`p-4 rounded-md border transition-all ${
      highlight 
        ? 'bg-white/[0.04] border-white/20' 
        : 'bg-surface-1 border-white/10 hover:border-white/15'
    }`}>
      <div className="flex items-center justify-between text-xs text-neutral-400">
        <span className="font-mono text-[11px] uppercase tracking-wider text-neutral-400">{label}</span>
        {trend && (
          <span className={`inline-flex items-center gap-0.5 text-[11px] font-mono ${
            trend.direction === 'up' ? 'text-emerald-400' : 
            trend.direction === 'down' ? 'text-neutral-400' : 'text-neutral-500'
          }`}>
            {trend.direction === 'up' && <ArrowUpRight className="w-3 h-3" />}
            {trend.direction === 'down' && <ArrowDownRight className="w-3 h-3" />}
            {trend.direction === 'neutral' && <Minus className="w-3 h-3" />}
            {trend.value}
          </span>
        )}
      </div>
      <div className="mt-2 text-2xl md:text-3xl font-normal tracking-tight text-white font-sans">
        {value}
      </div>
      {sublabel && (
        <div className="mt-1 text-[11px] text-neutral-500 font-mono">
          {sublabel}
        </div>
      )}
    </div>
  );
};

export const BudgetBar: React.FC<{ 
  current: number; 
  limit: number; 
  label?: string;
  size?: 'sm' | 'md';
  showLabels?: boolean;
}> = ({ current, limit, label, size = 'md', showLabels = true }) => {
  const percent = limit > 0 ? Math.min(100, Math.round((current / limit) * 100)) : 0;
  
  // Subtle risk tinting: stays monochrome gray/silver until 90%+
  let barColor = 'bg-neutral-300';
  let badgeColor = 'text-neutral-400';
  if (percent >= 90) {
    barColor = 'bg-amber-400';
    badgeColor = 'text-amber-400';
  }
  if (percent >= 100) {
    barColor = 'bg-red-400';
    badgeColor = 'text-red-400';
  }

  const height = size === 'sm' ? 'h-1' : 'h-1.5';

  return (
    <div className="w-full space-y-1">
      {showLabels && (
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-neutral-400">{label || 'Daily Budget'}</span>
          <span className={badgeColor}>
            ${current.toFixed(2)} / ${limit.toFixed(2)} ({percent}%)
          </span>
        </div>
      )}
      <div className={`w-full ${height} bg-neutral-900 rounded-full overflow-hidden border border-white/10`}>
        <div 
          className={`${height} ${barColor} transition-all duration-300 rounded-full`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
};
