import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

export const PayflowLogo: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 20 }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Geometric symbol: two vertical rounded flow pillars connected by an authorization bridge */}
    <rect x="3" y="4" width="6" height="16" rx="3" fill="url(#metalGrad1)" />
    <rect x="15" y="4" width="6" height="16" rx="3" fill="url(#metalGrad2)" />
    <path d="M9 12H15" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
    <circle cx="12" cy="12" r="1.5" fill="white" />
    <defs>
      <linearGradient id="metalGrad1" x1="6" y1="4" x2="6" y2="20" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="1" stopColor="#8A8A8A" />
      </linearGradient>
      <linearGradient id="metalGrad2" x1="18" y1="4" x2="18" y2="20" gradientUnits="userSpaceOnUse">
        <stop stopColor="#A0A0A0" />
        <stop offset="1" stopColor="#FFFFFF" />
      </linearGradient>
    </defs>
  </svg>
);

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'emergency';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  loadingText?: string;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'secondary',
  size = 'md',
  loading = false,
  loadingText,
  icon,
  className = '',
  disabled,
  ...props
}) => {
  const base = "inline-flex items-center justify-center font-medium rounded-md transition-all duration-150 focus:outline-none focus:ring-1 focus:ring-white/40 disabled:opacity-40 disabled:cursor-not-allowed select-none";
  
  const sizeStyles = {
    sm: "text-xs px-2.5 py-1.2 gap-1.5 h-7",
    md: "text-xs px-3.5 py-2 gap-2 h-8",
    lg: "text-sm px-4 py-2.5 gap-2.5 h-10",
  }[size];

  const variantStyles = {
    primary: "metal-button-primary",
    secondary: "metal-button-secondary",
    ghost: "bg-transparent text-silver hover:text-white hover:bg-white/[0.04] border border-transparent",
    danger: "bg-red-950/20 text-red-300 border border-red-800/40 hover:bg-red-900/30 hover:border-red-700/60",
    emergency: "bg-white text-black font-semibold hover:bg-neutral-200 shadow-metal",
  }[variant];

  return (
    <button
      className={cn(base, sizeStyles, variantStyles, className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <>
          <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
          <span>{loadingText || children}</span>
        </>
      ) : (
        <>
          {icon && <span className="shrink-0">{icon}</span>}
          {children}
        </>
      )}
    </button>
  );
};

export const StatusBadge: React.FC<{ 
  status: 'APPROVED' | 'PENDING' | 'PENDING_APPROVAL' | 'BLOCKED' | 'REJECTED' | 'FAILED' | 'COMPLETED' | 'active' | 'paused' | 'stopped' | 'disabled';
  className?: string;
}> = ({ status, className = '' }) => {
  let tFunc: ((k: any) => string) | null = null;
  try {
    const { t } = require('@/context/PayflowContext').usePayflow();
    tFunc = t;
  } catch (e) {
    // context not ready or used outside provider
  }

  const norm = status.toUpperCase();

  const labels: Record<string, string> = {
    APPROVED: tFunc ? tFunc('status.approved') : 'Approved',
    COMPLETED: tFunc ? tFunc('status.completed') : 'Completed',
    ACTIVE: tFunc ? tFunc('status.active') : 'Active',
    PENDING: tFunc ? tFunc('status.pending') : 'Pending',
    PENDING_APPROVAL: tFunc ? tFunc('status.needsApproval') : 'Needs Approval',
    BLOCKED: tFunc ? tFunc('status.blocked') : 'Blocked',
    REJECTED: tFunc ? tFunc('status.rejected') : 'Rejected',
    FAILED: tFunc ? tFunc('status.failed') : 'Failed',
    PAUSED: tFunc ? tFunc('status.paused') : 'Paused',
    STOPPED: tFunc ? tFunc('status.disabled') : 'Disabled',
  };

  const config: Record<string, { icon: string; style: string }> = {
    APPROVED: { icon: '✓', style: 'bg-emerald-950/30 text-emerald-300/90 border-emerald-800/40' },
    COMPLETED: { icon: '✓', style: 'bg-emerald-950/30 text-emerald-300/90 border-emerald-800/40' },
    ACTIVE: { icon: '●', style: 'bg-emerald-950/30 text-emerald-300/90 border-emerald-800/40' },
    PENDING: { icon: '◷', style: 'bg-amber-950/30 text-amber-300/90 border-amber-800/40' },
    PENDING_APPROVAL: { icon: '◷', style: 'bg-amber-950/30 text-amber-300/90 border-amber-800/40' },
    BLOCKED: { icon: '×', style: 'bg-red-950/30 text-red-300/90 border-red-800/40' },
    REJECTED: { icon: '×', style: 'bg-red-950/30 text-red-300/90 border-red-800/40' },
    FAILED: { icon: '!', style: 'bg-red-950/30 text-red-300/90 border-red-800/40' },
    PAUSED: { icon: '❚❚', style: 'bg-neutral-900 text-neutral-400 border-neutral-700/50' },
    STOPPED: { icon: '■', style: 'bg-red-950/40 text-red-400 border-red-800/60' },
  };

  const itemStyle = config[norm] || { icon: '•', style: 'bg-neutral-900 text-neutral-400 border-neutral-800' };
  const labelText = labels[norm] || status;

  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium border tracking-wide",
      itemStyle.style,
      className
    )}>
      <span className="text-[10px] leading-none opacity-80" aria-hidden="true">{itemStyle.icon}</span>
      <span>{labelText}</span>
    </span>
  );
};

export const RiskBadge: React.FC<{ risk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'; className?: string }> = ({ risk, className = '' }) => {
  let tFunc: ((k: any) => string) | null = null;
  try {
    const { t } = require('@/context/PayflowContext').usePayflow();
    tFunc = t;
  } catch (e) {
    // ignore
  }

  const styles = {
    LOW: "text-neutral-300 bg-neutral-900/90 border-white/10",
    MEDIUM: "text-amber-200 bg-amber-950/30 border-amber-800/30",
    HIGH: "text-orange-200 bg-orange-950/30 border-orange-800/40",
    CRITICAL: "text-red-200 bg-red-950/40 border-red-800/60 font-semibold",
  }[risk];

  const riskLabels = {
    LOW: tFunc ? tFunc('risk.low') : 'LOW',
    MEDIUM: tFunc ? tFunc('risk.medium') : 'MEDIUM',
    HIGH: tFunc ? tFunc('risk.high') : 'HIGH',
    CRITICAL: tFunc ? tFunc('risk.critical') : 'CRITICAL',
  };

  return (
    <span className={cn(
      "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider border",
      styles,
      className
    )}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {riskLabels[risk] || risk}
    </span>
  );
};

export const SimulationBadge: React.FC<{ className?: string }> = ({ className = '' }) => (
  <span className={cn(
    "inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white/[0.04] text-neutral-300 border border-white/15 text-[10px] font-mono tracking-wider uppercase",
    className
  )}>
    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
    SIMULATION
  </span>
);
