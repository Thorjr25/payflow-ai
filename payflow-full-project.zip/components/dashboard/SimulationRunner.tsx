'use client';

import React, { useState } from 'react';
import { usePayflow } from '@/context/PayflowContext';
import { Button, StatusBadge, RiskBadge } from '@/components/ui';
import { Play, Sparkles, CheckCircle2, AlertCircle, ShieldAlert } from 'lucide-react';
import { PolicyEvaluationResult } from '@/types';

export const SimulationRunner: React.FC = () => {
  const { 
    agents, 
    simulatePayment, 
    emergencyStopActive, 
    triggerEmergencyStop, 
    resumeEmergencyStop 
  } = usePayflow();

  const [selectedScenario, setSelectedScenario] = useState<string>('A');
  const [running, setRunning] = useState(false);
  const [lastResult, setLastResult] = useState<PolicyEvaluationResult | null>(null);

  // Predefined master demo scenarios from specifications
  const scenarios = [
    {
      id: 'A',
      title: 'Scenario A — Auto Approval',
      agentId: 'agent-research-01',
      service: 'MarketData Pro',
      amount: 0.10,
      purpose: 'Hourly S&P index market quote pull',
      expected: 'APPROVED (Under $0.50 threshold, service authorized)',
    },
    {
      id: 'B',
      title: 'Scenario B — Human Approval Required',
      agentId: 'agent-research-01',
      service: 'Premium Dataset',
      amount: 0.72,
      purpose: 'Full historical BTC tick archive purchase',
      expected: 'PENDING APPROVAL (Exceeds $0.50 threshold)',
    },
    {
      id: 'C',
      title: 'Scenario C — Per-Tx Limit Exceeded',
      agentId: 'agent-research-01',
      service: 'MarketData Pro',
      amount: 2.00,
      purpose: 'Institutional order book historical depth',
      expected: 'BLOCKED (Exceeds $1.00 per-transaction cap)',
    },
    {
      id: 'D',
      title: 'Scenario D — Daily Budget Exceeded',
      agentId: 'agent-news-02',
      service: 'News API',
      amount: 0.50,
      purpose: 'Real-time wire feed continuous crawl',
      expected: 'BLOCKED (News Scanner already spent $4.83 of $5.00)',
    },
    {
      id: 'E',
      title: 'Scenario E — Unauthorized Service',
      agentId: 'agent-market-03',
      service: 'Unverified Broker API',
      amount: 0.15,
      purpose: 'Direct socket execution bridge probe',
      expected: 'BLOCKED (Vendor blocklisted / unauthorized)',
    },
  ];

  const activeScenario = scenarios.find(s => s.id === selectedScenario) || scenarios[0];

  const handleRun = () => {
    setRunning(true);
    setTimeout(() => {
      const result = simulatePayment({
        agentId: activeScenario.agentId,
        service: activeScenario.service,
        amount: activeScenario.amount,
        purpose: activeScenario.purpose,
      });
      setLastResult(result);
      setRunning(false);
    }, 450);
  };

  return (
    <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-white" />
          <h3 className="text-xs font-mono uppercase tracking-wider text-white">
            Deterministic Simulation Center
          </h3>
        </div>
        <span className="text-[11px] font-mono text-neutral-400">
          Isolated Sandbox Rails (Zero Real Capital at Risk)
        </span>
      </div>

      <p className="text-xs text-neutral-400">
        Trigger predefined autonomous payment workflows to test the deterministic policy engine, budget updates, audit trails, and fail-closed security guarantees.
      </p>

      {/* Scenario Selector Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {scenarios.map((s) => (
          <button
            key={s.id}
            onClick={() => {
              setSelectedScenario(s.id);
              setLastResult(null);
            }}
            className={`px-3 py-2 rounded text-left border transition-all ${
              selectedScenario === s.id 
                ? 'bg-white/[0.08] border-white/30 text-white shadow-sm' 
                : 'bg-surface-2 border-white/5 text-neutral-400 hover:text-neutral-200 hover:bg-white/[0.02]'
            }`}
          >
            <div className="text-[11px] font-mono font-semibold">Scenario {s.id}</div>
            <div className="text-[10px] text-neutral-500 truncate mt-0.5">
              ${s.amount.toFixed(2)} → {s.service}
            </div>
          </button>
        ))}
      </div>

      {/* Active Scenario Card */}
      <div className="p-4 rounded-md bg-surface-2 border border-white/10 space-y-3 text-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <div className="font-semibold text-white text-sm">{activeScenario.title}</div>
            <div className="text-neutral-400 text-[11px] mt-0.5">
              Simulated Agent: <span className="text-white">{agents.find(a => a.id === activeScenario.agentId)?.name}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-base font-mono font-medium text-white">${activeScenario.amount.toFixed(2)} USD</div>
            <div className="text-[10px] text-neutral-500 font-mono">Simulated Access Cost</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] font-mono">
          <div className="bg-black/40 p-2.5 rounded border border-white/5 space-y-1">
            <div className="text-neutral-500">Target Service:</div>
            <div className="text-white font-medium">{activeScenario.service}</div>
          </div>
          <div className="bg-black/40 p-2.5 rounded border border-white/5 space-y-1">
            <div className="text-neutral-500">Declared Purpose:</div>
            <div className="text-neutral-300 truncate">{activeScenario.purpose}</div>
          </div>
        </div>

        <div className="p-2.5 rounded bg-white/[0.02] border border-white/5 flex items-center justify-between text-[11px]">
          <span className="text-neutral-400">Expected Result:</span>
          <span className="font-mono text-neutral-300">{activeScenario.expected}</span>
        </div>

        {/* Action button */}
        <div className="pt-2 flex items-center justify-between">
          <div className="text-[11px] text-neutral-500 font-mono">
            {emergencyStopActive ? (
              <span className="text-red-400 font-medium">⚠️ Emergency Stop Active (Guaranteed Block)</span>
            ) : (
              <span>Engine Status: Operational</span>
            )}
          </div>
          <Button 
            variant="primary" 
            size="md" 
            onClick={handleRun}
            loading={running}
            loadingText="Evaluating Policy Pipeline..."
            icon={<Play className="w-3.5 h-3.5 fill-current" />}
          >
            Execute Scenario {activeScenario.id}
          </Button>
        </div>
      </div>

      {/* Decision Output Inspector */}
      {lastResult && (
        <div className="p-4 rounded-md bg-surface-3 border border-white/20 space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase text-neutral-400">Engine Decision:</span>
              <StatusBadge status={lastResult.decision} />
              <RiskBadge risk={lastResult.riskLevel} />
            </div>
            <span className="text-[10px] font-mono text-neutral-500">
              Evaluated in 2.4ms (Deterministic)
            </span>
          </div>

          <div className="p-3 rounded bg-black/50 border border-white/10 text-xs font-mono space-y-1">
            <div className="text-neutral-400 text-[11px]">Official Reasoning:</div>
            <div className="text-white leading-relaxed">{lastResult.reason}</div>
          </div>

          <div className="space-y-1.5 pt-1">
            <div className="text-[11px] font-mono text-neutral-400 uppercase">Policy Rules Executed:</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {lastResult.checks.map((check, i) => (
                <div key={i} className="flex items-start gap-2 p-2 rounded bg-white/[0.02] border border-white/5">
                  {check.passed ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                  )}
                  <div className="overflow-hidden">
                    <div className="text-white font-medium text-[11px]">{check.name}</div>
                    <div className="text-neutral-400 text-[10px] font-mono truncate">{check.details}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
