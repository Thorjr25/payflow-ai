'use client';

import React, { useState } from 'react';
import { SpendingPoint } from '@/types';

interface SpendingChartProps {
  data?: SpendingPoint[];
}

export const SpendingChart: React.FC<SpendingChartProps> = () => {
  const [timeframe, setTimeframe] = useState<'7D' | '30D' | '90D'>('7D');
  const [hoveredPoint, setHoveredPoint] = useState<{
    date: string;
    approved: number;
    blocked: number;
    total: number;
  } | null>(null);

  // Deterministic realistic spending datapoints for 7D
  const data7D = [
    { date: 'Aug 29', approved: 2.10, blocked: 0.00, total: 2.10, agent: 'Research Agent' },
    { date: 'Aug 30', approved: 4.80, blocked: 1.20, total: 6.00, agent: 'News Scanner' },
    { date: 'Aug 31', approved: 3.50, blocked: 0.00, total: 3.50, agent: 'Market Monitor' },
    { date: 'Sep 01', approved: 5.90, blocked: 2.50, total: 8.40, agent: 'Research Agent' },
    { date: 'Sep 02', approved: 4.20, blocked: 0.50, total: 4.70, agent: 'News Scanner' },
    { date: 'Sep 03', approved: 6.40, blocked: 2.00, total: 8.40, agent: 'Market Monitor' },
    { date: 'Sep 04 (Today)', approved: 9.77, blocked: 2.15, total: 11.92, agent: 'Research Agent' },
  ];

  const data30D = [
    { date: 'W1', approved: 24.50, blocked: 3.20, total: 27.70, agent: 'Multiple' },
    { date: 'W2', approved: 38.10, blocked: 5.40, total: 43.50, agent: 'Multiple' },
    { date: 'W3', approved: 52.80, blocked: 8.90, total: 61.70, agent: 'Multiple' },
    { date: 'W4 (Current)', approved: 48.20, blocked: 4.10, total: 52.30, agent: 'Multiple' },
  ];

  const activeData = timeframe === '7D' ? data7D : data30D;
  const maxTotal = Math.max(...activeData.map(d => d.total), 12);

  return (
    <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-300">
            Spending Activity
          </h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">
            Real-time approved vs. blocked autonomous allocations
          </p>
        </div>

        <div className="flex items-center gap-1 bg-surface-2 p-1 rounded border border-white/10 self-start sm:self-auto">
          {(['7D', '30D', '90D'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setTimeframe(tab)}
              className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
                timeframe === tab 
                  ? 'bg-white text-black font-semibold shadow-sm' 
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Chart */}
      <div className="relative pt-4 pb-2">
        <div className="h-44 w-full flex items-end justify-between gap-2 md:gap-4 px-2">
          {activeData.map((point, index) => {
            const approvedHeight = (point.approved / maxTotal) * 100;
            const blockedHeight = (point.blocked / maxTotal) * 100;

            return (
              <div 
                key={index}
                className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                onMouseEnter={() => setHoveredPoint(point)}
                onMouseLeave={() => setHoveredPoint(null)}
              >
                {/* Visual Bar Stack */}
                <div className="w-full max-w-[36px] flex flex-col justify-end h-full">
                  {/* Blocked Attempt Segment */}
                  {point.blocked > 0 && (
                    <div 
                      className="w-full bg-red-900/60 border-t border-red-500/40 rounded-t transition-all group-hover:bg-red-800/80"
                      style={{ height: `${blockedHeight}%` }}
                    />
                  )}
                  {/* Approved Spend Segment */}
                  <div 
                    className="w-full bg-gradient-to-t from-neutral-300 to-white border-t border-white/40 rounded-t transition-all group-hover:from-neutral-200 group-hover:to-white shadow-metal"
                    style={{ height: `${approvedHeight}%` }}
                  />
                </div>

                {/* X-axis Label */}
                <span className="mt-2 text-[10px] font-mono text-neutral-500 truncate w-full text-center">
                  {point.date}
                </span>
              </div>
            );
          })}
        </div>

        {/* Hover Inspector Tooltip */}
        {hoveredPoint && (
          <div className="absolute top-2 right-4 bg-surface-3 border border-white/20 px-3.5 py-2.5 rounded-md shadow-xl text-xs space-y-1 font-mono pointer-events-none animate-in fade-in duration-100">
            <div className="text-white font-semibold border-b border-white/10 pb-1 flex justify-between gap-4">
              <span>{hoveredPoint.date}</span>
              <span className="text-neutral-400">Total: ${hoveredPoint.total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4 text-emerald-300">
              <span>Approved Spend:</span>
              <span>${hoveredPoint.approved.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4 text-red-300">
              <span>Blocked Attempts:</span>
              <span>${hoveredPoint.blocked.toFixed(2)}</span>
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-end gap-6 pt-2 border-t border-white/5 text-[11px] font-mono text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-sm bg-white shadow-sm" />
          <span>Approved Spend</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-sm bg-red-800/80 border border-red-500/40" />
          <span>Blocked Attempts</span>
        </div>
      </div>
    </div>
  );
};
