'use client';

import React from 'react';
import Link from 'next/link';
import { usePayflow } from '@/context/PayflowContext';
import { StatusBadge, RiskBadge } from '@/components/ui';
import { ChevronRight } from 'lucide-react';

export const RecentRequestsTable: React.FC = () => {
  const { transactions, pendingRequests } = usePayflow();

  // Combine top recent pending and completed/blocked requests for comprehensive view
  const combined = [
    ...pendingRequests.map(p => ({
      id: p.id,
      time: p.createdAt ? new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Pending',
      agentName: p.agentId === 'agent-research-01' ? 'Research Agent' : p.agentId === 'agent-news-02' ? 'News Scanner' : 'Agent',
      service: p.service,
      purpose: p.purpose,
      amount: p.amount,
      policyName: 'Research Policy',
      status: 'PENDING_APPROVAL' as const,
      riskLevel: p.riskLevel,
      link: '/approvals'
    })),
    ...transactions.slice(0, 5).map(t => ({
      id: t.id,
      time: t.createdAt ? new Date(t.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recent',
      agentName: t.agentName,
      service: t.service,
      purpose: t.purpose,
      amount: t.amount,
      policyName: 'Configured Policy',
      status: t.decision as any,
      riskLevel: t.riskLevel,
      link: `/transactions/${t.id}`
    }))
  ].slice(0, 6);

  return (
    <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-300">
            Recent Payment Requests
          </h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">
            Incoming micro-purchases evaluated against active policies
          </p>
        </div>
        <Link 
          href="/transactions" 
          className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 font-mono group"
        >
          <span>Transaction Logs</span>
          <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>

      <div className="overflow-x-auto -mx-5 px-5">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-neutral-500">
              <th className="py-2.5 pr-4 font-normal">Time</th>
              <th className="py-2.5 px-4 font-normal">Agent</th>
              <th className="py-2.5 px-4 font-normal">Service</th>
              <th className="py-2.5 px-4 font-normal">Purpose</th>
              <th className="py-2.5 px-4 font-normal text-right">Amount</th>
              <th className="py-2.5 pl-4 font-normal text-right">Decision</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {combined.map((item) => (
              <tr 
                key={item.id}
                className="hover:bg-white/[0.02] transition-colors group cursor-pointer"
                onClick={() => window.location.href = item.link}
              >
                <td className="py-3 pr-4 font-mono text-neutral-500 text-[11px]">
                  {item.time}
                </td>
                <td className="py-3 px-4 font-medium text-white group-hover:text-neutral-200">
                  {item.agentName}
                </td>
                <td className="py-3 px-4 text-neutral-300 font-mono text-[11px]">
                  {item.service}
                </td>
                <td className="py-3 px-4 text-neutral-400 truncate max-w-xs">
                  {item.purpose}
                </td>
                <td className="py-3 px-4 text-right font-mono font-medium text-white">
                  ${item.amount.toFixed(2)}
                </td>
                <td className="py-3 pl-4 text-right">
                  <StatusBadge status={item.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
