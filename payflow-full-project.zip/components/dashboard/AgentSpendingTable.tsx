'use client';

import React from 'react';
import Link from 'next/link';
import { usePayflow } from '@/context/PayflowContext';
import { StatusBadge } from '@/components/ui';
import { ChevronRight } from 'lucide-react';

export const AgentSpendingTable: React.FC = () => {
  const { agents } = usePayflow();

  return (
    <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-mono uppercase tracking-wider text-neutral-300">
            Agent Budget Utilization
          </h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">
            Active daily spending caps vs. real-time consumption
          </p>
        </div>
        <Link 
          href="/agents" 
          className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 font-mono group"
        >
          <span>View All Agents</span>
          <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>

      <div className="overflow-x-auto -mx-5 px-5">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-neutral-500">
              <th className="py-2.5 pr-4 font-normal">Agent</th>
              <th className="py-2.5 px-4 font-normal">Spent Today</th>
              <th className="py-2.5 px-4 font-normal">Daily Limit</th>
              <th className="py-2.5 px-4 font-normal w-48">Utilization</th>
              <th className="py-2.5 pl-4 font-normal text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {agents.map((agent) => {
              const percent = agent.dailyLimit > 0 
                ? Math.min(100, Math.round((agent.currentDailySpend / agent.dailyLimit) * 100)) 
                : 0;

              let statusText = 'Healthy';
              if (percent >= 90) statusText = 'Near Limit';
              if (agent.currentDailySpend === 0) statusText = 'Idle';
              if (agent.status === 'paused') statusText = 'Paused';

              return (
                <tr 
                  key={agent.id}
                  className="hover:bg-white/[0.02] transition-colors group cursor-pointer"
                  onClick={() => window.location.href = `/agents/${agent.id}`}
                >
                  <td className="py-3 pr-4">
                    <div className="font-medium text-white group-hover:text-neutral-200 transition-colors">
                      {agent.name}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate max-w-xs font-mono">
                      {agent.category || agent.description}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-white">
                    ${agent.currentDailySpend.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 font-mono text-neutral-400">
                    ${agent.dailyLimit.toFixed(2)}/day
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-white/10">
                        <div 
                          className={`h-full rounded-full ${
                            percent >= 90 ? 'bg-amber-400' : 'bg-neutral-200'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                      <span className={`text-[11px] font-mono shrink-0 ${
                        percent >= 90 ? 'text-amber-300 font-semibold' : 'text-neutral-400'
                      }`}>
                        {percent}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3 pl-4 text-right">
                    <StatusBadge status={agent.status} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
