'use client';

import React, { useState } from 'react';
import { usePayflow } from '@/context/PayflowContext';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui';
import { Check, ShieldCheck } from 'lucide-react';

interface CreateAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateAgentModal: React.FC<CreateAgentModalProps> = ({ isOpen, onClose }) => {
  const { createAgent, policies } = usePayflow();

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  
  // Form state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Market Research');
  const [dailyLimit, setDailyLimit] = useState(5.00);
  const [transactionLimit, setTransactionLimit] = useState(1.00);
  const [monthlyLimit, setMonthlyLimit] = useState(100.00);
  const [allowedServices, setAllowedServices] = useState<string[]>(['MarketData Pro', 'News API']);
  const [approvalThreshold, setApprovalThreshold] = useState(0.50);
  const [policyId, setPolicyId] = useState('policy-research');

  const availableServices = [
    'MarketData Pro',
    'News API',
    'MacroData',
    'Dataset Hub',
    'Research Cloud',
    'On-chain RPC',
    'Compute Instance',
  ];

  const toggleService = (srv: string) => {
    if (allowedServices.includes(srv)) {
      setAllowedServices(allowedServices.filter(s => s !== srv));
    } else {
      setAllowedServices([...allowedServices, srv]);
    }
  };

  const handleFinish = () => {
    createAgent({
      name: name.trim() || 'New Agent',
      description: description.trim() || 'Automated task worker',
      status: 'active',
      dailyLimit,
      transactionLimit,
      monthlyLimit,
      policyId: policyId || policies[0]?.id || 'policy-research',
      category
    });
    // reset
    setStep(1);
    setName('');
    setDescription('');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create Autonomous Agent"
      subtitle={`Step ${step} of 5 — Establish strict spending bounds`}
      maxWidth="lg"
    >
      <div className="space-y-5">
        {/* Step indicator */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          {[
            { num: 1, label: 'Identity' },
            { num: 2, label: 'Limits' },
            { num: 3, label: 'Services' },
            { num: 4, label: 'Approvals' },
            { num: 5, label: 'Review' },
          ].map((s) => (
            <div key={s.num} className="flex items-center gap-1.5 text-[11px] font-mono">
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === s.num ? 'bg-white text-black font-bold' : 
                step > s.num ? 'bg-neutral-800 text-neutral-300' : 'bg-neutral-900 text-neutral-600'
              }`}>
                {step > s.num ? '✓' : s.num}
              </span>
              <span className={step === s.num ? 'text-white' : 'text-neutral-500'}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        {/* Step 1: Identity */}
        {step === 1 && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Agent Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Quantitative Execution Agent"
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white placeholder:text-neutral-600 focus:outline-none focus:border-white/40"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Operational Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white focus:outline-none focus:border-white/40 font-mono text-xs"
              >
                <option value="Market Research">Market Research & Intelligence</option>
                <option value="Data Extraction">Data & Document Extraction</option>
                <option value="Algorithmic Execution">Algorithmic Order Execution</option>
                <option value="Reporting & Analytics">Reporting & Analytics</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Functional Purpose & Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe what tasks this agent performs and why payment access is required..."
                rows={3}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white placeholder:text-neutral-600 focus:outline-none focus:border-white/40"
              />
            </div>
          </div>
        )}

        {/* Step 2: Limits */}
        {step === 2 && (
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded bg-white/[0.02] border border-white/10 text-neutral-400 text-[11px]">
              PAYFLOW enforces these ceilings deterministically. The agent can never spend a penny more than these limits.
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Daily Spending Limit (USD)
              </label>
              <input
                type="number"
                step="0.50"
                min="0.10"
                value={dailyLimit}
                onChange={(e) => setDailyLimit(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none focus:border-white/40"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                Maximum cumulative spend allowed in a 24-hour UTC window.
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Per-Transaction Limit (USD)
              </label>
              <input
                type="number"
                step="0.10"
                min="0.05"
                value={transactionLimit}
                onChange={(e) => setTransactionLimit(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none focus:border-white/40"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                Any single purchase attempt exceeding this will be blocked immediately.
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Monthly Spending Ceiling (USD)
              </label>
              <input
                type="number"
                step="5.00"
                min="1.00"
                value={monthlyLimit}
                onChange={(e) => setMonthlyLimit(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none focus:border-white/40"
              />
            </div>
          </div>
        )}

        {/* Step 3: Allowed Services */}
        {step === 3 && (
          <div className="space-y-3 text-xs">
            <div className="text-[11px] text-neutral-400">
              Select verified vendor endpoints this agent is authorized to purchase from. Any unselected service will fail closed.
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
              {availableServices.map((srv) => {
                const selected = allowedServices.includes(srv);
                return (
                  <button
                    key={srv}
                    type="button"
                    onClick={() => toggleService(srv)}
                    className={`flex items-center justify-between p-3 rounded border text-left transition-all ${
                      selected 
                        ? 'bg-white/[0.08] border-white/30 text-white' 
                        : 'bg-black/50 border-white/10 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <span className="font-mono text-xs">{srv}</span>
                    {selected && <Check className="w-3.5 h-3.5 text-white" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 4: Approval Rules */}
        {step === 4 && (
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Require Human Operator Approval Above (USD)
              </label>
              <input
                type="number"
                step="0.05"
                min="0.01"
                value={approvalThreshold}
                onChange={(e) => setApprovalThreshold(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none focus:border-white/40"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                Purchases at or below this amount will execute autonomously. Purchases above will pause and route to Pending Approvals.
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Assign Master Policy Baseline
              </label>
              <select
                value={policyId}
                onChange={(e) => setPolicyId(e.target.value)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none focus:border-white/40"
              >
                {policies.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Step 5: Review */}
        {step === 5 && (
          <div className="space-y-4 text-xs">
            <div className="p-3.5 rounded bg-white/[0.03] border border-white/10 space-y-2 font-mono text-[11px]">
              <div className="flex justify-between border-b border-white/10 pb-1.5">
                <span className="text-neutral-500">Agent Name:</span>
                <span className="text-white font-semibold">{name || 'Unnamed Agent'}</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1.5">
                <span className="text-neutral-500">Daily Spending Limit:</span>
                <span className="text-white">${dailyLimit.toFixed(2)}/day</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1.5">
                <span className="text-neutral-500">Per-Transaction Limit:</span>
                <span className="text-white">${transactionLimit.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1.5">
                <span className="text-neutral-500">Monthly Spending Limit:</span>
                <span className="text-white">${monthlyLimit.toFixed(2)}/month</span>
              </div>
              <div className="flex justify-between border-b border-white/10 pb-1.5">
                <span className="text-neutral-500">Autonomous Threshold:</span>
                <span className="text-white">Under ${approvalThreshold.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-neutral-500 block mb-1">Authorized Services:</span>
                <span className="text-neutral-300">
                  {allowedServices.length > 0 ? allowedServices.join(', ') : 'None (Strictly Locked)'}
                </span>
              </div>
            </div>

            <div className="p-3 rounded bg-emerald-950/20 border border-emerald-800/30 text-emerald-200 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Fail-Closed Guarantee:</strong> This agent will only be able to spend within these explicitly declared permissions.
              </span>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-white/10">
          <Button
            variant="ghost"
            size="md"
            onClick={() => {
              if (step > 1) setStep((step - 1) as any);
              else onClose();
            }}
          >
            {step === 1 ? 'Cancel' : 'Back'}
          </Button>

          {step < 5 ? (
            <Button
              variant="primary"
              size="md"
              onClick={() => setStep((step + 1) as any)}
            >
              Continue
            </Button>
          ) : (
            <Button
              variant="primary"
              size="md"
              onClick={handleFinish}
            >
              Commit & Create Agent
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
};
