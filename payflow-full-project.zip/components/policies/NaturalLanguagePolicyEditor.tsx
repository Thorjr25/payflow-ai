'use client';

import React, { useState } from 'react';
import { usePayflow } from '@/context/PayflowContext';
import { Button } from '@/components/ui';
import { Sparkles, Check, ArrowRight, Shield } from 'lucide-react';

interface ParsedPolicy {
  agentName: string;
  dailyLimit: number;
  perTxLimit: number;
  approvalThreshold: number;
  allowedServices: string[];
}

export const NaturalLanguagePolicyEditor: React.FC = () => {
  const { createPolicy, agents } = usePayflow();
  const [prompt, setPrompt] = useState(
    'Let my research agent spend up to $5 per day on approved data services, but require approval for purchases over 50 cents.'
  );
  const [parsed, setParsed] = useState<ParsedPolicy | null>(null);
  const [policyName, setPolicyName] = useState('Natural Language Research Policy');

  const handleParse = () => {
    // Deterministic extraction based on natural language
    const lower = prompt.toLowerCase();
    
    // Daily spend match
    const dailyMatch = lower.match(/(?:\$|usd\s*)?(\d+(?:\.\d+)?)\s*(?:per day|\/day|daily)/);
    const daily = dailyMatch ? parseFloat(dailyMatch[1]) : 5.00;

    // Approval threshold match
    const approvalMatch = lower.match(/(?:approval for purchases over|approval above|above|over)\s*(?:\$|usd\s*)?(\d+(?:\.\d+)?)/);
    const approval = approvalMatch ? parseFloat(approvalMatch[1]) : 0.50;

    // Agent name match
    let targetAgent = 'Research Agent';
    if (lower.includes('news')) targetAgent = 'News Scanner';
    if (lower.includes('market')) targetAgent = 'Market Monitor';

    setParsed({
      agentName: targetAgent,
      dailyLimit: daily,
      perTxLimit: Math.min(daily, 1.00),
      approvalThreshold: approval,
      allowedServices: ['MarketData Pro', 'News API', 'MacroData']
    });
  };

  const handleCommit = () => {
    if (!parsed) return;
    createPolicy({
      name: policyName,
      description: `Generated from instruction: "${prompt}"`,
      agentIds: ['agent-research-01'],
      dailyLimit: parsed.dailyLimit,
      transactionLimit: parsed.perTxLimit,
      monthlyLimit: parsed.dailyLimit * 20,
      allowedServices: parsed.allowedServices,
      blockedServices: ['Arbitrary Payment', 'Unverified Swap'],
      approvalThreshold: parsed.approvalThreshold,
      riskLevel: 'LOW',
      status: 'active'
    });
    setParsed(null);
  };

  return (
    <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-white" />
          <h3 className="text-xs font-mono uppercase tracking-wider text-white">
            Natural Language Policy Generator
          </h3>
        </div>
        <span className="text-[11px] font-mono text-neutral-400">
          Plain English → Deterministic Rule Matrix
        </span>
      </div>

      <p className="text-xs text-neutral-400">
        Describe your spending policy in standard english. PAYFLOW will parse it into strict, deterministic boundaries for operator review before activation.
      </p>

      <div className="space-y-2">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={2}
          className="w-full px-3.5 py-2.5 rounded-md bg-surface-2 border border-white/15 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-white/40 font-mono"
        />
        <div className="flex justify-end">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleParse}
            icon={<ArrowRight className="w-3.5 h-3.5" />}
          >
            Parse Policy Structure
          </Button>
        </div>
      </div>

      {parsed && (
        <div className="p-4 rounded bg-surface-2 border border-white/20 space-y-3 animate-in fade-in duration-200">
          <div className="text-xs font-semibold text-white flex items-center justify-between border-b border-white/10 pb-2">
            <span>Parsed Policy Blueprint (Review Required)</span>
            <span className="text-[10px] font-mono text-neutral-400">Never Silently Activated</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <div className="text-neutral-500 text-[10px]">Target Agent:</div>
              <div className="text-white font-medium">{parsed.agentName}</div>
            </div>
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <div className="text-neutral-500 text-[10px]">Daily Limit:</div>
              <div className="text-white font-medium">${parsed.dailyLimit.toFixed(2)}</div>
            </div>
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <div className="text-neutral-500 text-[10px]">Per-Tx Limit:</div>
              <div className="text-white font-medium">${parsed.perTxLimit.toFixed(2)}</div>
            </div>
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <div className="text-neutral-500 text-[10px]">Approval Threshold:</div>
              <div className="text-amber-300 font-medium">&gt; ${parsed.approvalThreshold.toFixed(2)}</div>
            </div>
          </div>

          <div className="text-xs text-neutral-300 font-mono">
            <span className="text-neutral-500">Allowed Endpoints: </span>
            {parsed.allowedServices.join(', ')}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-white/10">
            <input
              type="text"
              value={policyName}
              onChange={(e) => setPolicyName(e.target.value)}
              className="px-2.5 py-1 rounded bg-black border border-white/15 text-xs text-white font-mono w-64"
            />
            <Button
              variant="primary"
              size="sm"
              onClick={handleCommit}
              icon={<Check className="w-3.5 h-3.5" />}
            >
              Commit & Activate Policy
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
