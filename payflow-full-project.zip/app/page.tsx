'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { PayflowLogo, Button, SimulationBadge } from '@/components/ui';
import { FluidClouds } from '@/components/ui/FluidClouds';
import { 
  ArrowRight, 
  Sparkles,
  Shield,
  Activity,
  ChevronRight,
  Lock,
  CheckCircle2
} from 'lucide-react';

import { usePayflow } from '@/context/PayflowContext';

export default function LandingPage() {
  const { language, setLanguage, t } = usePayflow();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 18 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" as const }
    },
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between selection:bg-white selection:text-black relative overflow-hidden">
      {/* Top Navbar sitting atop the global contrast scrim */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="border-b border-white/10 bg-black/60 backdrop-blur-2xl sticky top-0 z-50"
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <PayflowLogo size={22} className="animate-float" />
            <span className="font-semibold text-xs tracking-widest uppercase text-white drop-shadow-sm">PAYFLOW</span>
            <span className="hidden sm:inline text-neutral-400 font-mono text-[10px]">
              / {t('nav.tagline')}
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-xs font-mono text-neutral-300">
            <a href="#how-it-works" className="hover:text-white transition-colors">{t('nav.howItWorks')}</a>
            <a href="#architecture" className="hover:text-white transition-colors">{t('nav.architecture')}</a>
            <a href="#security" className="hover:text-white transition-colors">{t('nav.security')}</a>
          </nav>

          <div className="flex items-center gap-3">
            {/* Quick Language Toggle */}
            <div className="flex items-center gap-1 bg-surface-1 p-0.5 rounded border border-white/10 text-xs">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                  language === 'en' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('zh')}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                  language === 'zh' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                中文
              </button>
            </div>

            <SimulationBadge className="hidden sm:inline-flex" />
            <Link href="/dashboard">
              <Button variant="primary" size="sm" icon={<ArrowRight className="w-3.5 h-3.5" />}>
                {t('nav.launchConsole')}
              </Button>
            </Link>
          </div>
        </div>
      </motion.header>

      {/* Foreground Content: Sitting on top of the overlay, WCAG AAA compliant */}
      <main className="flex-1 relative z-10">
        <section className="relative pt-18 pb-20 md:pt-28 md:pb-32">
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="max-w-5xl mx-auto px-6 text-center space-y-8"
          >
            {/* Top Pill Badge */}
            <motion.div variants={itemVariants} className="inline-block">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-surface-2/90 border border-white/20 text-[11px] font-mono text-neutral-200 backdrop-blur-xl shadow-glass hover:border-white/40 transition-colors">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="tracking-wide">{t('landing.tagline')}</span>
              </div>
            </motion.div>

            {/* Main Heading - Pure White, Maximum Readability & Contrast */}
            <motion.h1 
              variants={itemVariants}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-normal tracking-tight text-white leading-[1.12] max-w-4xl mx-auto drop-shadow-md"
            >
              {t('landing.heroTitle1')} <span className="font-serif italic text-white font-normal underline decoration-white/30 underline-offset-8">{t('landing.heroTitleHighlight')}</span> {t('landing.heroTitle2')} <br className="hidden sm:inline" />
              {t('landing.heroTitle3')}
            </motion.h1>

            {/* Subheading - High-contrast light gray (#E2E8F0 equivalent), perfectly legible */}
            <motion.p 
              variants={itemVariants}
              className="text-base sm:text-lg text-neutral-200 max-w-2xl mx-auto leading-relaxed font-normal drop-shadow-sm"
            >
              {t('landing.heroDesc')}
            </motion.p>

            {/* CTAs with hover animation */}
            <motion.div variants={itemVariants} className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3.5">
              <Link href="/dashboard">
                <Button variant="primary" size="lg" icon={<ArrowRight className="w-4 h-4" />}>
                  {t('landing.getStarted')}
                </Button>
              </Link>
              <a href="#how-it-works">
                <Button variant="secondary" size="lg" icon={<Sparkles className="w-3.5 h-3.5 text-neutral-300" />}>
                  {t('landing.viewDocs')}
                </Button>
              </a>
            </motion.div>

            {/* Live Payment Workflow Visualizer */}
            <motion.div 
              variants={itemVariants}
              whileHover={{ y: -3, transition: { duration: 0.2 } }}
              className="pt-8 max-w-3xl mx-auto"
            >
              <div className="p-6 rounded-xl bg-surface-1/95 border border-white/15 backdrop-blur-2xl shadow-glass space-y-4 text-left relative overflow-hidden group">
                {/* Dynamic sheen overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.04] to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />

                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs font-mono uppercase tracking-wider text-neutral-200 font-medium">
                      Live Payment Pipeline Evaluation
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-neutral-400 bg-white/[0.05] px-2 py-0.5 rounded border border-white/10">
                    SIMULATION RAILS
                  </span>
                </div>

                {/* Workflow Horizontal Interactive Steps */}
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5 text-xs font-mono">
                  {[
                    { step: '1. Agent', label: 'Research Agent', glow: false },
                    { step: '2. Request', label: '$0.10 Quote', glow: false },
                    { step: '3. Engine', label: 'Check Rules', glow: false },
                    { step: '4. Decision', label: '✓ Approved', glow: true },
                    { step: '5. Access', label: 'HTTP 200', glow: false },
                    { step: '6. Audit', label: 'SIM-TX-8F3', glow: false },
                  ].map((item, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: 1.04, y: -2 }}
                      className={`p-2.5 rounded-lg bg-surface-2 border flex flex-col justify-between transition-colors ${
                        item.glow 
                          ? 'border-emerald-500/50 bg-emerald-950/40 text-emerald-300 font-semibold' 
                          : 'border-white/10 hover:border-white/25 text-white'
                      }`}
                    >
                      <span className="text-neutral-400 text-[9px] uppercase font-mono">{item.step}</span>
                      <span className="font-medium truncate mt-1">{item.label}</span>
                    </motion.div>
                  ))}
                </div>

                <div className="p-3.5 rounded-lg bg-black/70 border border-white/10 flex items-center justify-between text-xs font-mono">
                  <span className="text-neutral-300 font-medium">Deterministic Result:</span>
                  <span className="text-white">
                    Within $1.00 transaction limit and daily allowance ($3.82 / $5.00).
                  </span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </section>

        {/* 4-Stage Product Story Section with Motion */}
        <section id="how-it-works" className="py-20 border-t border-white/10 bg-black/40 relative">
          <div className="max-w-6xl mx-auto px-6 space-y-12">
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center space-y-2 max-w-xl mx-auto"
            >
              <div className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider">
                Deterministic Execution
              </div>
              <h2 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                Every payment follows a policy.
              </h2>
              <p className="text-xs text-neutral-300 leading-relaxed font-normal">
                The control plane between autonomous agent execution layers and real-world payment infrastructure.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { num: '01', title: 'REQUEST', heading: 'An agent requests payment.', desc: 'Autonomous agents query for premium APIs, datasets, or compute instances with a declared purchase intent and amount.' },
                { num: '02', title: 'CHECK', heading: 'PAYFLOW evaluates policy.', desc: 'Deterministic inspection verifies agent status, service allowlist, per-tx caps, daily budgets, and monthly ceilings.' },
                { num: '03', title: 'APPROVE', heading: 'Automatic or routed.', desc: 'Under-threshold transactions disburse immediately. High-value or anomaly attempts route to human operator inbox.' },
                { num: '04', title: 'RECORD', heading: 'Immutable audit trail.', desc: 'Every decision, rule result, and actor intervention is cryptographically logged with zero credential exposure.' },
              ].map((card, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  whileHover={{ y: -4, borderColor: 'rgba(255,255,255,0.3)' }}
                  className="p-6 rounded-xl bg-surface-1/90 border border-white/10 space-y-3 shadow-glass backdrop-blur-xl transition-all"
                >
                  <div className="text-xs font-mono text-neutral-400 uppercase">{card.num} / {card.title}</div>
                  <h3 className="text-base font-medium text-white">{card.heading}</h3>
                  <p className="text-xs text-neutral-300 leading-relaxed">{card.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Trust & Architecture Metrics */}
        <section id="architecture" className="py-16 border-t border-white/10 bg-black/40 relative">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
              {[
                { stat: '$0.10', label: 'Typical Micro-Payment Tier', sub: 'Precision sub-cent tracking' },
                { stat: '100%', label: 'Policy-Controlled', sub: 'Zero unmonitored disbursements' },
                { stat: 'FAIL CLOSED', label: 'Autonomous Safety', sub: 'Unverified requests abort' },
              ].map((m, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, scale: 0.96 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: idx * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="p-6 rounded-xl bg-surface-1/90 border border-white/10 space-y-1.5 shadow-glass backdrop-blur-xl transition-all"
                >
                  <div className="text-3xl font-mono font-medium text-white">{m.stat}</div>
                  <div className="text-xs font-mono uppercase text-neutral-300 mt-1">{m.label}</div>
                  <div className="text-[11px] text-neutral-400 font-mono">{m.sub}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Restrained Minimal Footer */}
      <footer className="border-t border-white/10 py-8 bg-black/90 backdrop-blur-md relative z-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-2">
            <PayflowLogo size={16} />
            <span className="text-white font-semibold uppercase">PAYFLOW</span>
            <span>© 2026. The payment control plane for AI agents.</span>
          </div>

          <div className="flex items-center gap-6">
            <Link href="/dashboard" className="hover:text-white transition-colors">Console</Link>
            <Link href="/security" className="hover:text-white transition-colors">Security</Link>
            <Link href="/integrations" className="hover:text-white transition-colors">API & Specs</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
