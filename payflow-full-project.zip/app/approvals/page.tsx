'use client';

import React, { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button, StatusBadge, RiskBadge } from '@/components/ui';
import { BudgetBar } from '@/components/ui/Metric';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  ChevronRight, 
  ExternalLink,
  Sliders
} from 'lucide-react';
import { PaymentRequest } from '@/types';
import { ConfirmationModal, Modal } from '@/components/ui/Modal';

export default function ApprovalsPage() {
  const { 
    pendingRequests, 
    agents, 
    policies, 
    approvePaymentRequest, 
    rejectPaymentRequest, 
    createApprovalRule,
    emergencyStopActive,
    t
  } = usePayflow();

  const [selectedReq, setSelectedReq] = useState<PaymentRequest | null>(
    pendingRequests.length > 0 ? pendingRequests[0] : null
  );

  const [ruleModalOpen, setRuleModalOpen] = useState(false);
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [approving, setApproving] = useState(false);

  // Derive agent and budget impact for selected request
  const activeAgent = selectedReq ? agents.find(a => a.id === selectedReq.agentId) : null;
  const activePolicy = selectedReq ? policies.find(p => p.id === selectedReq.policyId) : null;

  const currentSpend = activeAgent?.currentDailySpend || 0;
  const reqAmount = selectedReq?.amount || 0;
  const dailyLimit = activeAgent?.dailyLimit || 5.00;
  const afterSpend = currentSpend + reqAmount;
  const remainingAfter = Math.max(0, dailyLimit - afterSpend);

  const handleApprove = () => {
    if (!selectedReq) return;
    setApproving(true);
    setTimeout(() => {
      approvePaymentRequest(selectedReq.id);
      setApproving(false);
      // Select next pending request or clear
      const remaining = pendingRequests.filter(r => r.id !== selectedReq.id);
      setSelectedReq(remaining.length > 0 ? remaining[0] : null);
    }, 350);
  };

  const handleRejectConfirm = () => {
    if (!selectedReq) return;
    rejectPaymentRequest(selectedReq.id, rejectReason || 'Declined by human operator');
    setRejectModalOpen(false);
    setRejectReason('');
    const remaining = pendingRequests.filter(r => r.id !== selectedReq.id);
    setSelectedReq(remaining.length > 0 ? remaining[0] : null);
  };

  const handleCreateRuleConfirm = () => {
    if (!selectedReq) return;
    createApprovalRule(selectedReq.agentId, selectedReq.service, Math.max(selectedReq.amount, 1.00));
    setRuleModalOpen(false);
    handleApprove();
  };

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.approvals')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('approvals.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('approvals.subtitle')}
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs text-neutral-400">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>{pendingRequests.length} {t('status.pending')}</span>
          </div>
        </div>

        {/* Emergency Stop Active Notification */}
        {emergencyStopActive && (
          <div className="p-3.5 rounded-md bg-red-950/20 border border-red-800/40 text-red-200 text-xs flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <div>
              <strong>Action Prohibited:</strong> Global payment emergency stop is active. Approvals are paused and fail closed.
            </div>
          </div>
        )}

        {/* Master-Detail Split Layout */}
        {pendingRequests.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Queue List (5 Cols) */}
            <div className="lg:col-span-5 space-y-2.5">
              <div className="text-[11px] font-mono text-neutral-500 uppercase px-1">
                Authorization Queue
              </div>
              <div className="space-y-2">
                {pendingRequests.map((req) => {
                  const agent = agents.find(a => a.id === req.agentId);
                  const isSelected = selectedReq?.id === req.id;

                  return (
                    <div
                      key={req.id}
                      onClick={() => setSelectedReq(req)}
                      className={`p-4 rounded-md border text-xs cursor-pointer transition-all ${
                        isSelected 
                          ? 'bg-surface-2 border-white/30 shadow-md' 
                          : 'bg-surface-1 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-semibold text-white">{agent?.name || 'Agent'}</span>
                        <span className="font-mono text-white text-sm">${req.amount.toFixed(2)}</span>
                      </div>
                      <div className="text-neutral-400 font-mono text-[11px] truncate mb-2">
                        {req.service}
                      </div>
                      <p className="text-neutral-500 text-[11px] line-clamp-2 mb-2 leading-relaxed">
                        {req.purpose}
                      </p>
                      <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono">
                        <span className="text-neutral-500">2 min ago</span>
                        <RiskBadge risk={req.riskLevel} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Detailed Approval Inspector (7 Cols) */}
            {selectedReq && activeAgent && (
              <div className="lg:col-span-7 p-6 rounded-md bg-surface-1 border border-white/15 space-y-5 sticky top-20">
                {/* Header detail */}
                <div className="flex items-start justify-between border-b border-white/10 pb-4">
                  <div>
                    <div className="text-[11px] font-mono text-neutral-400 uppercase">Payment Request Authorization</div>
                    <h2 className="text-lg font-semibold text-white mt-0.5">{activeAgent.name}</h2>
                    <div className="text-xs text-neutral-400 font-mono mt-0.5">Target: {selectedReq.service}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-mono font-medium text-white">${selectedReq.amount.toFixed(2)}</div>
                    <div className="text-[10px] font-mono text-neutral-500">USD (Simulation Rails)</div>
                  </div>
                </div>

                {/* Stated Purpose */}
                <div className="p-3.5 rounded bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono uppercase text-neutral-500">Declared Purchase Intent:</div>
                  <div className="text-xs text-neutral-200 leading-relaxed font-sans">{selectedReq.purpose}</div>
                </div>

                {/* Policy Check Breakdown */}
                <div className="space-y-2">
                  <div className="text-[11px] font-mono uppercase text-neutral-400">Automated Policy Validation:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-2 p-2.5 rounded bg-white/[0.02] border border-white/5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="text-white font-medium text-[11px]">Agent Identity</div>
                        <div className="text-[10px] font-mono text-neutral-400">Authenticated & Active</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2.5 rounded bg-white/[0.02] border border-white/5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="text-white font-medium text-[11px]">Service Allowlist</div>
                        <div className="text-[10px] font-mono text-neutral-400">{selectedReq.service} is authorized</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2.5 rounded bg-white/[0.02] border border-white/5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="text-white font-medium text-[11px]">Transaction Limit</div>
                        <div className="text-[10px] font-mono text-neutral-400">Within ${activeAgent.transactionLimit.toFixed(2)} cap</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2.5 rounded bg-white/[0.02] border border-white/5">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      <div>
                        <div className="text-amber-300 font-medium text-[11px]">Approval Threshold</div>
                        <div className="text-[10px] font-mono text-amber-400/80">&gt; ${activePolicy?.approvalThreshold.toFixed(2) || '0.50'} limit</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Real-time Budget Impact Calculation */}
                <div className="p-4 rounded bg-surface-2 border border-white/10 space-y-3">
                  <div className="flex items-center justify-between text-[11px] font-mono uppercase text-neutral-400">
                    <span>Projected Daily Budget Impact</span>
                    <span>Daily Ceiling: ${dailyLimit.toFixed(2)}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs font-mono text-center">
                    <div className="p-2 rounded bg-black/50 border border-white/5">
                      <span className="text-neutral-500 block text-[10px]">Current Spend</span>
                      <span className="text-neutral-300 font-medium">${currentSpend.toFixed(2)}</span>
                    </div>
                    <div className="p-2 rounded bg-black/50 border border-white/5">
                      <span className="text-neutral-500 block text-[10px]">This Purchase</span>
                      <span className="text-white font-medium">+${reqAmount.toFixed(2)}</span>
                    </div>
                    <div className="p-2 rounded bg-black/50 border border-white/5">
                      <span className="text-neutral-500 block text-[10px]">Post-Approval</span>
                      <span className="text-white font-bold">${afterSpend.toFixed(2)}</span>
                    </div>
                  </div>

                  <BudgetBar current={afterSpend} limit={dailyLimit} label="Projected Spend" />

                  <div className="text-[11px] font-mono text-neutral-400 flex justify-between">
                    <span>Remaining post-transaction:</span>
                    <span className="text-white font-semibold">${remainingAfter.toFixed(2)}</span>
                  </div>
                </div>

                {/* Decision Actions */}
                <div className="pt-2 border-t border-white/10 space-y-2.5">
                  <div className="flex flex-wrap items-center gap-3">
                    <Button
                      variant="primary"
                      size="md"
                      onClick={handleApprove}
                      loading={approving}
                      loadingText="Authorizing Funds..."
                      disabled={emergencyStopActive}
                    >
                      {t('approvals.approveBtn')} (${selectedReq.amount.toFixed(2)})
                    </Button>

                    <Button
                      variant="danger"
                      size="md"
                      onClick={() => setRejectModalOpen(true)}
                    >
                      {t('approvals.rejectBtn')}
                    </Button>

                    <Button
                      variant="secondary"
                      size="md"
                      icon={<Sliders className="w-3.5 h-3.5" />}
                      onClick={() => setRuleModalOpen(true)}
                    >
                      {t('approvals.createRuleBtn')}
                    </Button>
                  </div>

                  <p className="text-[10px] text-neutral-500 font-mono">
                    Approving will commit the transaction to the immutable audit log and disburse mock settlement funds.
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Empty state */
          <div className="p-12 text-center rounded-md bg-surface-1 border border-white/10 space-y-3 max-w-md mx-auto my-12">
            <ShieldCheck className="w-8 h-8 text-neutral-400 mx-auto" />
            <h3 className="text-sm font-semibold text-white">{t('approvals.emptyTitle')}</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              {t('approvals.emptySubtitle')}
            </p>
          </div>
        )}

        {/* Reject Confirmation Dialog */}
        <Modal
          isOpen={rejectModalOpen}
          onClose={() => setRejectModalOpen(false)}
          title="Reject Payment Request"
          subtitle="Deny autonomous capital access"
        >
          <div className="space-y-4 text-xs">
            <p className="text-neutral-300">
              Are you sure you want to deny this payment of <strong className="text-white font-mono">${selectedReq?.amount.toFixed(2)}</strong> for {selectedReq?.service}?
            </p>
            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Reason for Rejection (Logged to Audit Trail)
              </label>
              <input
                type="text"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g. Excessive cost for query batch / unapproved query scope"
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
            </div>
            <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
              <Button variant="ghost" size="md" onClick={() => setRejectModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="danger" size="md" onClick={handleRejectConfirm}>
                Confirm Rejection
              </Button>
            </div>
          </div>
        </Modal>

        {/* Smart Approval Rule Creation Modal */}
        <Modal
          isOpen={ruleModalOpen}
          onClose={() => setRuleModalOpen(false)}
          title="Create Autonomous Exemption Rule"
          subtitle="Elevate autonomous spending permissions"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded bg-amber-950/20 border border-amber-800/30 text-amber-200 text-[11px]">
              <span className="font-semibold">Permission Warning: </span>
              This rule will allow future payments matching these conditions without manual human approval.
            </div>

            <div className="p-3 rounded bg-black/40 border border-white/10 space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-neutral-500">Agent:</span>
                <span className="text-white">{activeAgent?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Service Endpoint:</span>
                <span className="text-white">{selectedReq?.service}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Max Autonomous Amount:</span>
                <span className="text-white">${Math.max(selectedReq?.amount || 1.00, 1.00).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Rule Expiration:</span>
                <span className="text-white">Never (Until manually revoked)</span>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
              <Button variant="ghost" size="md" onClick={() => setRuleModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="md" onClick={handleCreateRuleConfirm}>
                Commit Rule & Approve Now
              </Button>
            </div>
          </div>
        </Modal>
      </div>
    </AppShell>
  );
}
