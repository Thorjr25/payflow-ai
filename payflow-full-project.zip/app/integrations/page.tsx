'use client';

import React from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button } from '@/components/ui';
import { Sliders, Key, Server, CheckCircle2, Code2, AlertTriangle } from 'lucide-react';

export default function IntegrationsPage() {
  const { t } = usePayflow();

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-5xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.controlSystem')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.integrations')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('integrations.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('integrations.subtitle')}
            </p>
          </div>
        </div>

        {/* Rails Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white text-sm">Deterministic Simulation Provider</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/30 text-emerald-300 border border-emerald-800/40">
                ACTIVE
              </span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Provides isolated, deterministic execution of autonomous payment requests. Simulates settlement latency, verifies allowlists, and enforces all policy thresholds.
            </p>
            <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-neutral-500">
              Provider status: Operational (Fail-Closed)
            </div>
          </div>

          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white text-sm">X402 HTTP Native Payment Rail</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-neutral-900 text-neutral-400 border border-white/10">
                ADAPTER READY
              </span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Designed to intercept HTTP 402 Payment Required status headers, evaluate policy, and complete programmatic micro-settlements over Lightning, USDC, or credit rails.
            </p>
            <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-neutral-500">
              Credentials: Non-Custodial Vault Protected
            </div>
          </div>
        </div>

        {/* API Specification & Request Body Example */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/10 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-white" />
              <h3 className="text-xs font-mono uppercase tracking-wider text-white">
                Programmatic Agent Payment Request API
              </h3>
            </div>
            <span className="text-[11px] font-mono text-emerald-400">POST /api/payment/request</span>
          </div>

          <p className="text-xs text-neutral-400">
            AI agents interact with PAYFLOW via standard HTTP JSON envelopes. The policy engine evaluates the request and returns an authorized decision before funds move.
          </p>

          <div className="p-4 rounded bg-black border border-white/10 font-mono text-xs text-neutral-300 overflow-x-auto">
            <div className="text-neutral-500">// Example Agent Request Payload</div>
            <pre className="text-emerald-300 mt-1">{`POST /api/payment/request
Host: api.payflow.ai
Authorization: Bearer agent_tok_secops_9921

{
  "agent": "research-agent",
  "service": "market-data-pro",
  "amount": 0.10,
  "currency": "USD",
  "purpose": "BTC hourly market depth quote"
}`}</pre>

            <div className="text-neutral-500 mt-4">// Deterministic PAYFLOW Engine Response</div>
            <pre className="text-neutral-200 mt-1">{`HTTP/1.1 200 OK
Content-Type: application/json

{
  "decision": "APPROVED",
  "reason": "Within configured policy limits ($0.10 < $1.00)",
  "transactionId": "SIM-TX-8F3A19",
  "environment": "simulation",
  "timestamp": "2026-09-04T22:08:24Z"
}`}</pre>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
