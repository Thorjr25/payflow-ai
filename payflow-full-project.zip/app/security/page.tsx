'use client';

import React, { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button } from '@/components/ui';
import { 
  AlertOctagon, 
  ShieldCheck, 
  Lock, 
  Server, 
  Eye, 
  History, 
  CheckCircle2,
  Key
} from 'lucide-react';
import { ConfirmationModal } from '@/components/ui/Modal';

export default function SecurityPage() {
  const { 
    emergencyStopActive, 
    triggerEmergencyStop, 
    resumeEmergencyStop,
    auditEvents,
    language,
    setLanguage,
    addToast,
    t
  } = usePayflow();

  const [confirmStopOpen, setConfirmStopOpen] = useState(false);
  const [sessionTimeout, setSessionTimeout] = useState('15');
  const [reauthSensitive, setReauthSensitive] = useState(true);
  const [globalThreshold, setGlobalThreshold] = useState('1.00');

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-5xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.controlSystem')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.security')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('security.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('security.subtitle')}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-neutral-300">{t('security.guarantee')}</span>
          </div>
        </div>

        {/* Section 1: Emergency Kill Switch */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/15 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-red-400" />
                <h3 className="text-sm font-semibold text-white">{t('security.killSwitchTitle')}</h3>
              </div>
              <p className="text-xs text-neutral-400 max-w-xl leading-relaxed">
                {t('security.killSwitchDesc')}
              </p>
            </div>

            {emergencyStopActive ? (
              <Button
                variant="primary"
                size="md"
                onClick={resumeEmergencyStop}
              >
                {t('emergency.deactivate')}
              </Button>
            ) : (
              <Button
                variant="danger"
                size="md"
                icon={<AlertOctagon className="w-3.5 h-3.5" />}
                onClick={() => setConfirmStopOpen(true)}
              >
                {t('emergency.disableAll')}
              </Button>
            )}
          </div>

          <div className={`p-3 rounded border text-xs font-mono ${
            emergencyStopActive 
              ? 'bg-red-950/40 border-red-800/60 text-red-200' 
              : 'bg-black/40 border-white/5 text-neutral-400'
          }`}>
            {t('security.statusLabel')}{' '}
            <strong className={emergencyStopActive ? 'text-red-300' : 'text-emerald-400'}>
              {emergencyStopActive ? t('security.statusBlocked') : t('security.statusActive')}
            </strong>
          </div>
        </div>

        {/* Section 2: Core Architectural Principles */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-white text-xs font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{t('security.policyFirst')}</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {t('security.policyFirstDesc')}
            </p>
          </div>

          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-white text-xs font-semibold">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>{t('security.failClosed')}</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {t('security.failClosedDesc')}
            </p>
          </div>

          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-white text-xs font-semibold">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>{t('security.zeroLeakage')}</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {t('security.zeroLeakageDesc')}
            </p>
          </div>
        </div>

        {/* Section 2.5: Language & Localization Settings */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/15 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <span>🌐</span>
                <span>{t('language.title')}</span>
              </h3>
              <p className="text-neutral-400 text-xs">
                {t('language.subtitle')}
              </p>
            </div>
            <div className="text-[11px] font-mono text-neutral-400">
              {t('language.activeLang')}{' '}
              <span className="text-white font-semibold uppercase">
                {language === 'zh' ? '中文 (zh)' : 'English (en)'}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 pt-1">
            <button
              onClick={() => {
                setLanguage('en');
                addToast('Language set to English', 'info');
              }}
              className={`flex items-center gap-2.5 px-4 py-2.5 rounded-md border text-xs font-medium transition-all ${
                language === 'en'
                  ? 'bg-white text-black font-semibold border-white shadow-lg'
                  : 'bg-black/40 border-white/10 text-neutral-300 hover:text-white hover:border-white/30'
              }`}
            >
              <span className="text-sm">🇺🇸</span>
              <span>English (US)</span>
              {language === 'en' && <CheckCircle2 className="w-3.5 h-3.5 ml-1 text-black" />}
            </button>

            <button
              onClick={() => {
                setLanguage('zh');
                addToast('已切换至中文界面 (Simplified Chinese)', 'success');
              }}
              className={`flex items-center gap-2.5 px-4 py-2.5 rounded-md border text-xs font-medium transition-all ${
                language === 'zh'
                  ? 'bg-white text-black font-semibold border-white shadow-lg'
                  : 'bg-black/40 border-white/10 text-neutral-300 hover:text-white hover:border-white/30'
              }`}
            >
              <span className="text-sm">🇨🇳</span>
              <span>简体中文 (Chinese)</span>
              {language === 'zh' && <CheckCircle2 className="w-3.5 h-3.5 ml-1 text-black" />}
            </button>
          </div>
        </div>

        {/* Section 3: Global Governance Settings */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/10 space-y-4 text-xs">
          <h3 className="text-xs font-mono uppercase tracking-wider text-white">
            {t('security.thresholdsTitle')}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-mono text-neutral-400 uppercase mb-1">
                {t('security.hardCap')}
              </label>
              <input
                type="number"
                step="0.25"
                value={globalThreshold}
                onChange={(e) => setGlobalThreshold(e.target.value)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                {t('security.hardCapHelp')}
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-neutral-400 uppercase mb-1">
                {t('security.sessionTimeout')}
              </label>
              <select
                value={sessionTimeout}
                onChange={(e) => setSessionTimeout(e.target.value)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none text-xs"
              >
                <option value="15">15 Minutes (High Security)</option>
                <option value="30">30 Minutes (Standard)</option>
                <option value="60">60 Minutes</option>
              </select>
              <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                {t('security.timeoutHelp')}
              </span>
            </div>
          </div>
        </div>

        {/* Section 4: System Audit Timeline */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/10 space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              {t('security.auditLogTitle')}
            </h3>
            <span className="text-[10px] font-mono text-neutral-500">{t('security.immutableTrail')}</span>
          </div>

          <div className="space-y-2.5 pt-1">
            {auditEvents.slice(0, 8).map((event) => (
              <div 
                key={event.id}
                className="flex items-start justify-between gap-3 p-2.5 rounded bg-black/40 border border-white/5 text-xs font-mono"
              >
                <div className="space-y-0.5">
                  <div className="text-white">{event.message}</div>
                  <div className="text-[10px] text-neutral-500">
                    Actor: <span className="text-neutral-300">{event.actor}</span> • Type: {event.type}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] text-neutral-500 block">
                    {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className={`text-[10px] font-semibold ${
                    event.result === 'SUCCESS' ? 'text-emerald-400' : 
                    event.result === 'BLOCKED' ? 'text-red-400' : 'text-amber-400'
                  }`}>
                    {event.result}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Stop Confirmation Modal */}
        <ConfirmationModal
          isOpen={confirmStopOpen}
          onClose={() => setConfirmStopOpen(false)}
          onConfirm={() => {
            triggerEmergencyStop();
            setConfirmStopOpen(false);
          }}
          title="Disable All Automated Payments?"
          description="Are you sure you want to trigger the global emergency stop? All current and upcoming agent payment requests will immediately fail closed and produce BLOCKED."
          consequence="100% of autonomous payment workflows will be completely halted across all agents until an administrator manually resets the kill switch."
          confirmText="Disable Payments Now"
          variant="danger"
        />
      </div>
    </AppShell>
  );
}
