'use client';

import React, { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button, StatusBadge } from '@/components/ui';
import { BudgetBar } from '@/components/ui/Metric';
import { 
  Pause, 
  Play, 
  AlertOctagon, 
  ShieldCheck, 
  ChevronLeft, 
  CheckCircle2, 
  XCircle,
  Sliders
} from 'lucide-react';
import { ConfirmationModal, Modal } from '@/components/ui/Modal';
import Link from 'next/link';

export default function AgentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const agentId = params?.id as string;
  const { 
    agents, 
    policies, 
    transactions, 
    toggleAgentPause, 
    updateAgent,
    triggerEmergencyStop 
  } = usePayflow();

  const agent = agents.find(a => a.id === agentId);
  const policy = policies.find(p => p.id === agent?.policyId);
  const agentTransactions = transactions.filter(t => t.agentId === agentId);

  const [editLimitsOpen, setEditLimitsOpen] = useState(false);
  const [newDaily, setNewDaily] = useState(agent?.dailyLimit || 5.00);
  const [newTxLimit, setNewTxLimit] = useState(agent?.transactionLimit || 1.00);
  const [newMonthly, setNewMonthly] = useState(agent?.monthlyLimit || 100.00);
  const [stopConfirmOpen, setStopConfirmOpen] = useState(false);

  if (!agent) {
    return (
      <AppShell>
        <div className="p-8 text-center space-y-4 max-w-md mx-auto my-20">
          <h2 className="text-lg font-semibold text-white">Agent Not Found</h2>
          <p className="text-xs text-neutral-400">The requested agent ID does not exist in this workspace.</p>
          <Link href="/agents">
            <Button variant="primary" size="md">Return to Agents</Button>
          </Link>
        </div>
      </AppShell>
    );
  }

  const handleSaveLimits = () => {
    updateAgent(agent.id, {
      dailyLimit: newDaily,
      transactionLimit: newTxLimit,
      monthlyLimit: newMonthly
    });
    setEditLimitsOpen(false);
  };

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider">
          <Link href="/agents" className="hover:text-white flex items-center gap-1">
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Agents</span>
          </Link>
          <span>/</span>
          <span className="text-neutral-300">{agent.name}</span>
        </div>

        {/* Header with Title & Action Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-semibold text-white tracking-tight">{agent.name}</h1>
              <StatusBadge status={agent.status} />
            </div>
            <p className="text-xs text-neutral-400 max-w-2xl">{agent.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Button
              variant="secondary"
              size="md"
              icon={agent.status === 'active' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              onClick={() => toggleAgentPause(agent.id)}
            >
              {agent.status === 'active' ? 'Pause Agent' : 'Resume Agent'}
            </Button>

            <Button
              variant="secondary"
              size="md"
              icon={<Sliders className="w-3.5 h-3.5" />}
              onClick={() => {
                setNewDaily(agent.dailyLimit);
                setNewTxLimit(agent.transactionLimit);
                setNewMonthly(agent.monthlyLimit);
                setEditLimitsOpen(true);
              }}
            >
              Edit Policies
            </Button>

            <Button
              variant="danger"
              size="md"
              icon={<AlertOctagon className="w-3.5 h-3.5" />}
              onClick={() => setStopConfirmOpen(true)}
            >
              Emergency Stop
            </Button>
          </div>
        </div>

        {/* Real-time Spend and Utilization Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-2">
            <div className="text-[11px] font-mono text-neutral-500 uppercase">Today's Spend</div>
            <div className="text-2xl font-mono text-white">
              ${agent.currentDailySpend.toFixed(2)}{' '}
              <span className="text-xs text-neutral-500">/ ${agent.dailyLimit.toFixed(2)}</span>
            </div>
            <BudgetBar current={agent.currentDailySpend} limit={agent.dailyLimit} showLabels={false} />
          </div>

          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-2">
            <div className="text-[11px] font-mono text-neutral-500 uppercase">Monthly Spend</div>
            <div className="text-2xl font-mono text-white">
              ${agent.currentMonthlySpend.toFixed(2)}{' '}
              <span className="text-xs text-neutral-500">/ ${agent.monthlyLimit.toFixed(2)}</span>
            </div>
            <BudgetBar current={agent.currentMonthlySpend} limit={agent.monthlyLimit} showLabels={false} />
          </div>

          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-1">
            <div className="text-[11px] font-mono text-neutral-500 uppercase">Lifetime Transactions</div>
            <div className="text-2xl font-mono text-white">{agentTransactions.length}</div>
            <div className="text-[10px] text-neutral-500 font-mono">Total payment requests processed</div>
          </div>

          <div className="p-4 rounded-md bg-surface-1 border border-white/10 space-y-1">
            <div className="text-[11px] font-mono text-neutral-500 uppercase">Blocked Violations</div>
            <div className="text-2xl font-mono text-red-300">
              {agentTransactions.filter(t => t.decision === 'BLOCKED').length}
            </div>
            <div className="text-[10px] text-neutral-500 font-mono">Attempted unauthorized spend blocked</div>
          </div>
        </div>

        {/* Grid: Current Permissions & Policy Evaluation Checks */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Current Permissions */}
          <div className="lg:col-span-2 p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider text-white">Current Permissions</h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">Boundaries enforced on every API/tool payment invocation</p>
              </div>
              <span className="text-[11px] font-mono text-emerald-400">Strict Enforcement</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 rounded bg-black/40 border border-white/5">
                <div className="text-neutral-500 text-[10px]">Daily Ceiling</div>
                <div className="text-white font-medium text-sm mt-1">${agent.dailyLimit.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded bg-black/40 border border-white/5">
                <div className="text-neutral-500 text-[10px]">Per-Transaction</div>
                <div className="text-white font-medium text-sm mt-1">${agent.transactionLimit.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded bg-black/40 border border-white/5">
                <div className="text-neutral-500 text-[10px]">Monthly Ceiling</div>
                <div className="text-white font-medium text-sm mt-1">${agent.monthlyLimit.toFixed(2)}</div>
              </div>
              <div className="p-3 rounded bg-black/40 border border-white/5">
                <div className="text-neutral-500 text-[10px]">Human Approval</div>
                <div className="text-amber-300 font-medium text-sm mt-1">&gt; ${policy?.approvalThreshold.toFixed(2) || '0.50'}</div>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <div className="text-xs font-mono text-neutral-400">Authorized Services Allowlist:</div>
              <div className="flex flex-wrap gap-1.5">
                {policy?.allowedServices.map((service) => (
                  <span key={service} className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white/[0.04] border border-white/10 text-xs text-neutral-300 font-mono">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    {service}
                  </span>
                ))}
              </div>
            </div>

            {policy?.blockedServices && policy.blockedServices.length > 0 && (
              <div className="space-y-2 pt-2">
                <div className="text-xs font-mono text-neutral-400">Explicit Blocklist:</div>
                <div className="flex flex-wrap gap-1.5">
                  {policy.blockedServices.map((service) => (
                    <span key={service} className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-red-950/20 border border-red-800/30 text-xs text-red-300 font-mono">
                      <XCircle className="w-3 h-3 text-red-400" />
                      {service}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Col: Active Policy Meta */}
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">Active Policy Rule</h3>
            <div className="p-3 rounded bg-black/40 border border-white/5 space-y-2 text-xs">
              <div className="font-semibold text-white">{policy?.name || 'Standard Data Policy'}</div>
              <p className="text-neutral-400 text-[11px] leading-relaxed">
                {policy?.description || 'Enforces deterministic budgets and human review on high-value items.'}
              </p>
              <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                <span>Risk Profile:</span>
                <span className="text-white">{policy?.riskLevel || 'LOW'}</span>
              </div>
            </div>

            <div className="p-3 rounded bg-white/[0.02] border border-white/5 space-y-1 text-xs">
              <div className="text-neutral-400 text-[11px] font-mono">Fail-Closed Boundary:</div>
              <div className="text-neutral-300 text-[11px] leading-relaxed">
                If the payment evaluation engine cannot contact authorization records, all spending fails closed automatically.
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity Timeline for this Agent */}
        <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-wider text-white">Recent Agent Activity & Logs</h3>
          <div className="overflow-x-auto -mx-5 px-5">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-neutral-500">
                  <th className="py-2.5 pr-4 font-normal">Transaction ID</th>
                  <th className="py-2.5 px-4 font-normal">Service</th>
                  <th className="py-2.5 px-4 font-normal">Purpose</th>
                  <th className="py-2.5 px-4 font-normal text-right">Amount</th>
                  <th className="py-2.5 pl-4 font-normal text-right">Decision</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {agentTransactions.length > 0 ? (
                  agentTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 pr-4 font-mono text-white text-[11px]">
                        <Link href={`/transactions/${tx.id}`} className="hover:underline">
                          {tx.id}
                        </Link>
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-300 text-[11px]">{tx.service}</td>
                      <td className="py-3 px-4 text-neutral-400 truncate max-w-sm">{tx.purpose}</td>
                      <td className="py-3 px-4 text-right font-mono font-medium text-white">${tx.amount.toFixed(2)}</td>
                      <td className="py-3 pl-4 text-right">
                        <StatusBadge status={tx.decision} />
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-neutral-500 font-mono text-xs">
                      No recorded payment attempts for this agent yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Edit Limits Modal */}
        <Modal
          isOpen={editLimitsOpen}
          onClose={() => setEditLimitsOpen(false)}
          title={`Edit Permissions: ${agent.name}`}
          subtitle="Adjust autonomous spending bounds"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded bg-amber-950/20 border border-amber-800/30 text-amber-200 text-[11px]">
              <strong>Permission Warning:</strong> Increasing spending bounds expands the agent's autonomous purchasing authority.
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Daily Ceiling (USD)
              </label>
              <input
                type="number"
                step="0.50"
                value={newDaily}
                onChange={(e) => setNewDaily(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Per-Transaction Limit (USD)
              </label>
              <input
                type="number"
                step="0.10"
                value={newTxLimit}
                onChange={(e) => setNewTxLimit(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Monthly Limit (USD)
              </label>
              <input
                type="number"
                step="5.00"
                value={newMonthly}
                onChange={(e) => setNewMonthly(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
              <Button variant="ghost" size="md" onClick={() => setEditLimitsOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="md" onClick={handleSaveLimits}>
                Apply New Limits
              </Button>
            </div>
          </div>
        </Modal>

        {/* Global Emergency Stop confirmation */}
        <ConfirmationModal
          isOpen={stopConfirmOpen}
          onClose={() => setStopConfirmOpen(false)}
          onConfirm={() => {
            triggerEmergencyStop();
            setStopConfirmOpen(false);
          }}
          title="Trigger Emergency Stop"
          description="Activate global emergency kill switch? All automated payment workflows across this agent and every other agent will immediately fail closed."
          consequence="100% of payment attempts will be blocked with reason: Global emergency stop active."
          confirmText="Disable All Payments"
          variant="danger"
        />
      </div>
    </AppShell>
  );
}
