'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button, StatusBadge } from '@/components/ui';
import { Plus, Bot, Pause, Play, Trash2, ArrowUpRight, Search } from 'lucide-react';
import { CreateAgentModal } from '@/components/agents/CreateAgentModal';
import { ConfirmationModal } from '@/components/ui/Modal';

export default function AgentsPage() {
  const { agents, toggleAgentPause, deleteAgent, t } = usePayflow();
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAgents = agents.filter(a => 
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.agents')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('agents.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('agents.subtitle')}
            </p>
          </div>

          <Button
            variant="primary"
            size="md"
            icon={<Plus className="w-3.5 h-3.5" />}
            onClick={() => setCreateModalOpen(true)}
          >
            {t('agents.createBtn')}
          </Button>
        </div>

        {/* Filters and Search */}
        <div className="flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('agents.searchPlaceholder')}
              className="w-full pl-9 pr-3 py-1.5 rounded-md bg-surface-1 border border-white/10 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-white/30 font-mono"
            />
          </div>
          <div className="text-[11px] font-mono text-neutral-500">
            {filteredAgents.length} active instances
          </div>
        </div>

        {/* Agents Table / List */}
        <div className="p-5 rounded-md bg-surface-1 border border-white/10">
          <div className="overflow-x-auto -mx-5 px-5">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-neutral-500">
                  <th className="py-2.5 pr-4 font-normal">Agent Identity</th>
                  <th className="py-2.5 px-4 font-normal">Daily Limit</th>
                  <th className="py-2.5 px-4 font-normal">Monthly Limit</th>
                  <th className="py-2.5 px-4 font-normal">Today's Spend</th>
                  <th className="py-2.5 px-4 font-normal">Last Active</th>
                  <th className="py-2.5 px-4 font-normal">Status</th>
                  <th className="py-2.5 pl-4 font-normal text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredAgents.map((agent) => {
                  const percent = agent.dailyLimit > 0 
                    ? Math.min(100, Math.round((agent.currentDailySpend / agent.dailyLimit) * 100)) 
                    : 0;

                  return (
                    <tr 
                      key={agent.id}
                      className="hover:bg-white/[0.02] transition-colors group"
                    >
                      <td className="py-3.5 pr-4">
                        <Link 
                          href={`/agents/${agent.id}`}
                          className="font-medium text-white group-hover:text-neutral-200 flex items-center gap-2"
                        >
                          <span>{agent.name}</span>
                          <ArrowUpRight className="w-3 h-3 text-neutral-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Link>
                        <div className="text-[11px] text-neutral-500 font-mono truncate max-w-sm mt-0.5">
                          {agent.description}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-white">
                        ${agent.dailyLimit.toFixed(2)}/day
                      </td>
                      <td className="py-3.5 px-4 font-mono text-neutral-400">
                        ${agent.monthlyLimit.toFixed(2)}/mo
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-mono text-white">
                          ${agent.currentDailySpend.toFixed(2)}
                        </div>
                        <div className="text-[10px] font-mono text-neutral-500">
                          {percent}% of daily cap
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-neutral-400 text-[11px]">
                        {agent.lastPaymentAt || 'Never'}
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusBadge status={agent.status} />
                      </td>
                      <td className="py-3.5 pl-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => toggleAgentPause(agent.id)}
                            className="p-1.5 rounded hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
                            title={agent.status === 'active' ? 'Pause Agent' : 'Resume Agent'}
                          >
                            {agent.status === 'active' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            onClick={() => setDeleteTargetId(agent.id)}
                            className="p-1.5 rounded hover:bg-red-950/40 text-neutral-500 hover:text-red-400 transition-colors"
                            title="Delete Agent"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modals */}
        <CreateAgentModal
          isOpen={createModalOpen}
          onClose={() => setCreateModalOpen(false)}
        />

        <ConfirmationModal
          isOpen={deleteTargetId !== null}
          onClose={() => setDeleteTargetId(null)}
          onConfirm={() => {
            if (deleteTargetId) deleteAgent(deleteTargetId);
            setDeleteTargetId(null);
          }}
          title="Delete Agent Instance"
          description="Are you sure you want to permanently remove this autonomous agent? All active session keys and pending allocations will be revoked."
          consequence="The agent will immediately lose all autonomous spending permissions and will fail closed on future payment requests."
          confirmText="Delete Agent"
          variant="danger"
        />
      </div>
    </AppShell>
  );
}
