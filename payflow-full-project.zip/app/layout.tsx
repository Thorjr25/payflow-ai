import type { Metadata } from "next";
import { Inter, Instrument_Serif } from "next/font/google";
import "./globals.css";
import { PayflowProvider } from "@/context/PayflowContext";
import { GlobalFluidBackground } from "@/components/ui/GlobalFluidBackground";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const instrumentSerif = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-instrument-serif",
  display: "swap",
});

export const metadata: Metadata = {
  title: "PAYFLOW — Agents that pay. Automatically, safely.",
  description: "AI-powered programmable payment management platform for AI agents and automated workflows. Policy-first, fail-closed financial infrastructure.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${instrumentSerif.variable}`}>
      <body className="bg-black text-white font-sans selection:bg-white selection:text-black min-h-screen relative">
        {/* Universal fixed animated fluid clouds & glass scrim across all app sections */}
        <GlobalFluidBackground />
        <PayflowProvider>
          {children}
        </PayflowProvider>
      </body>
    </html>
  );
}
