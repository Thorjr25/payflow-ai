'use client';

import React from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { Metric } from '@/components/ui/Metric';
import { SpendingChart } from '@/components/dashboard/SpendingChart';
import { AgentSpendingTable } from '@/components/dashboard/AgentSpendingTable';
import { RecentRequestsTable } from '@/components/dashboard/RecentRequestsTable';
import { SimulationRunner } from '@/components/dashboard/SimulationRunner';
import { usePayflow } from '@/context/PayflowContext';
import { AlertTriangle, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function DashboardPage() {
  const { agents, pendingRequests, transactions, t } = usePayflow();

  const totalMonthlySpend = agents.reduce((acc, a) => acc + a.currentMonthlySpend, 0);
  const activeAgentsCount = agents.filter(a => a.status === 'active').length;
  const pendingApprovalsCount = pendingRequests.length;
  const blockedAttemptsCount = transactions.filter(t => t.decision === 'BLOCKED').length;

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 12 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <AppShell>
      <motion.div 
        variants={container}
        initial="hidden"
        animate="visible"
        className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full"
      >
        {/* Page Header */}
        <motion.div variants={item} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.overview')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('dashboard.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('dashboard.subtitle')}
            </p>
          </div>

          <div className="flex items-center gap-3 self-start sm:self-auto">
            <Link
              href="/approvals"
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-white/[0.05] border border-white/10 hover:border-white/20 text-xs font-mono text-neutral-300 hover:text-white transition-all group"
            >
              <span>{t('dashboard.reviewPending')} ({pendingApprovalsCount})</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </Link>
          </div>
        </motion.div>

        {/* Security Alert Banner (If near limit or pending) */}
        {pendingApprovalsCount > 0 && (
          <motion.div variants={item} className="p-3.5 rounded-md bg-amber-950/20 border border-amber-800/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5 text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong className="font-semibold text-amber-300">{pendingApprovalsCount} {t('dashboard.alertPending')}</strong>
              </span>
            </div>
            <Link 
              href="/approvals" 
              className="font-mono text-amber-300 hover:underline text-[11px] font-medium shrink-0 ml-4"
            >
              {t('dashboard.openApprovals')}
            </Link>
          </motion.div>
        )}

        {/* Top 4 KPI Metrics */}
        <motion.div variants={item} className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          <Metric 
            label={t('dashboard.kpi.totalSpend')}
            value={`$${totalMonthlySpend.toFixed(2)}`}
            sublabel={t('dashboard.kpi.currentBilling')}
            trend={{ value: '+12.4%', direction: 'up' }}
          />
          <Metric 
            label={t('dashboard.kpi.activeAgents')}
            value={activeAgentsCount}
            sublabel={`${agents.length} ${t('dashboard.kpi.configured')}`}
            trend={{ value: '100%', direction: 'neutral' }}
          />
          <Metric 
            label={t('dashboard.kpi.pendingApprovals')}
            value={pendingApprovalsCount}
            sublabel={pendingApprovalsCount > 0 ? t('dashboard.kpi.needsHumanAction') : t('dashboard.kpi.allClear')}
            highlight={pendingApprovalsCount > 0}
          />
          <Metric 
            label={t('dashboard.kpi.blockedAttempts')}
            value={blockedAttemptsCount}
            sublabel={t('dashboard.kpi.failClosedEnforced')}
            trend={{ value: '+18.0%', direction: 'up' }}
          />
        </motion.div>

        {/* Spending Overview Chart */}
        <motion.div variants={item}>
          <SpendingChart />
        </motion.div>

        {/* Interactive Simulation Runner Drawer/Card */}
        <motion.div variants={item}>
          <SimulationRunner />
        </motion.div>

        {/* Agent Budget Utilization & Recent Requests Split */}
        <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AgentSpendingTable />
          <RecentRequestsTable />
        </motion.div>
      </motion.div>
    </AppShell>
  );
}
