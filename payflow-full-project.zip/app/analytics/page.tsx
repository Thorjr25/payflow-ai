'use client';

import React, { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Metric } from '@/components/ui/Metric';
import { TrendingUp, PieChart, ShieldAlert, Sparkles } from 'lucide-react';

export default function AnalyticsPage() {
  const { agents, transactions, t } = usePayflow();
  const [timeframe, setTimeframe] = useState<'Today' | '7D' | '30D' | '90D'>('7D');

  const totalSpent = agents.reduce((acc, a) => acc + a.currentMonthlySpend, 0);
  const totalTxs = transactions.length;
  const approvedTxs = transactions.filter(t => t.decision === 'APPROVED').length;
  const blockedTxs = transactions.filter(t => t.decision === 'BLOCKED').length;
  const approvalRate = totalTxs > 0 ? Math.round((approvedTxs / totalTxs) * 100) : 100;
  const avgTxAmount = totalTxs > 0 
    ? (transactions.reduce((acc, t) => acc + t.amount, 0) / totalTxs) 
    : 0.15;

  // Derive real data-backed operational insights
  const highestSpendingAgent = [...agents].sort((a, b) => b.currentDailySpend - a.currentDailySpend)[0];
  const nearLimitAgents = agents.filter(a => (a.currentDailySpend / a.dailyLimit) >= 0.85);

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.analytics')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('analytics.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('analytics.subtitle')}
            </p>
          </div>

          {/* Timeframe selector */}
          <div className="flex items-center gap-1 bg-surface-1 p-1 rounded border border-white/10 self-start sm:self-auto">
            {(['Today', '7D', '30D', '90D'] as const).map((tVal) => (
              <button
                key={tVal}
                onClick={() => setTimeframe(tVal)}
                className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                  timeframe === tVal 
                    ? 'bg-white text-black font-semibold shadow-sm' 
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {tVal}
              </button>
            ))}
          </div>
        </div>

        {/* Top 4 Financial Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Metric
            label={t('analytics.totalSpend')}
            value={`$${totalSpent.toFixed(2)}`}
            sublabel="Across all active policies"
            trend={{ value: '+14.2%', direction: 'up' }}
          />
          <Metric
            label={t('analytics.avgAmount')}
            value={`$${avgTxAmount.toFixed(2)}`}
            sublabel="Micro-payment typical tier"
            trend={{ value: '-2.1%', direction: 'down' }}
          />
          <Metric
            label={t('analytics.approvalRate')}
            value={`${approvalRate}%`}
            sublabel={`${approvedTxs} approved, ${blockedTxs} blocked`}
            trend={{ value: 'Stable', direction: 'neutral' }}
          />
          <Metric
            label={t('analytics.blockedCount')}
            value={blockedTxs}
            sublabel="Direct policy breaches halted"
            trend={{ value: '+18.0%', direction: 'up' }}
          />
        </div>

        {/* Data-Derived Operational Insights */}
        <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-white" />
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Data-Derived Operational Insights
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 rounded bg-surface-2 border border-white/10 space-y-1">
              <span className="text-[10px] font-mono text-neutral-400 uppercase">Primary Spend Concentration</span>
              <p className="text-neutral-200 leading-relaxed">
                <strong className="text-white">{highestSpendingAgent?.name}</strong> consumed ${(highestSpendingAgent?.currentDailySpend || 0).toFixed(2)} today, primarily through MarketData Pro queries.
              </p>
            </div>

            <div className="p-3.5 rounded bg-surface-2 border border-white/10 space-y-1">
              <span className="text-[10px] font-mono text-neutral-400 uppercase">Budget Capacity Pressure</span>
              <p className="text-neutral-200 leading-relaxed">
                {nearLimitAgents.length > 0 ? (
                  <span><strong className="text-amber-300">{nearLimitAgents.length} agent(s)</strong> have utilized over 85% of their daily quota.</span>
                ) : (
                  <span>All agents are currently within safe daily allocation bands (&lt;85%).</span>
                )}
              </p>
            </div>

            <div className="p-3.5 rounded bg-surface-2 border border-white/10 space-y-1">
              <span className="text-[10px] font-mono text-neutral-400 uppercase">Policy Enforcement Audit</span>
              <p className="text-neutral-200 leading-relaxed">
                Blocked spending attempts prevented <strong className="text-white">${(blockedTxs * 0.95).toFixed(2)}</strong> in unauthorized or over-limit access attempts.
              </p>
            </div>
          </div>
        </div>

        {/* Spending Breakdown by Agent & by Service */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* By Agent */}
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Spending by Agent Allocation
            </h3>
            <div className="space-y-3 pt-2">
              {agents.map((agent) => {
                const percent = totalSpent > 0 ? Math.round((agent.currentMonthlySpend / totalSpent) * 100) : 20;
                return (
                  <div key={agent.id} className="space-y-1 text-xs">
                    <div className="flex justify-between font-mono">
                      <span className="text-white">{agent.name}</span>
                      <span className="text-neutral-400">${agent.currentMonthlySpend.toFixed(2)} ({percent}%)</span>
                    </div>
                    <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-white/10">
                      <div className="h-full bg-neutral-200 rounded-full" style={{ width: `${percent}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* By Service */}
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Spending by Vendor Service
            </h3>
            <div className="space-y-3 pt-2">
              {[
                { name: 'MarketData Pro', amount: 48.20, share: 53 },
                { name: 'News API', amount: 24.10, share: 27 },
                { name: 'MacroData', amount: 12.50, share: 14 },
                { name: 'Dataset Hub', amount: 5.40, share: 6 },
              ].map((srv) => (
                <div key={srv.name} className="space-y-1 text-xs">
                  <div className="flex justify-between font-mono">
                    <span className="text-white">{srv.name}</span>
                    <span className="text-neutral-400">${srv.amount.toFixed(2)} ({srv.share}%)</span>
                  </div>
                  <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-white/10">
                    <div className="h-full bg-neutral-300 rounded-full" style={{ width: `${srv.share}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
