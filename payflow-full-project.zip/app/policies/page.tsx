'use client';

import React, { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { Button, StatusBadge, RiskBadge } from '@/components/ui';
import { ShieldCheck, Plus, CheckCircle2, XCircle, Sliders } from 'lucide-react';
import { NaturalLanguagePolicyEditor } from '@/components/policies/NaturalLanguagePolicyEditor';
import { Modal } from '@/components/ui/Modal';

export default function PoliciesPage() {
  const { policies, createPolicy, updatePolicy, agents, t } = usePayflow();
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // New policy state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [dailyLimit, setDailyLimit] = useState(5.00);
  const [txLimit, setTxLimit] = useState(1.00);
  const [monthlyLimit, setMonthlyLimit] = useState(100.00);
  const [approvalThreshold, setApprovalThreshold] = useState(0.50);

  const handleCreate = () => {
    createPolicy({
      name: name.trim() || 'Custom Policy',
      description: description.trim() || 'Deterministic policy rule',
      agentIds: ['agent-research-01'],
      dailyLimit,
      transactionLimit: txLimit,
      monthlyLimit,
      allowedServices: ['MarketData Pro', 'News API', 'MacroData'],
      blockedServices: ['Arbitrary Payment', 'Unverified Vendor'],
      approvalThreshold,
      riskLevel: 'LOW',
      status: 'active'
    });
    setCreateModalOpen(false);
  };

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.policies')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('policies.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('policies.subtitle')}
            </p>
          </div>

          <Button
            variant="primary"
            size="md"
            icon={<Plus className="w-3.5 h-3.5" />}
            onClick={() => setCreateModalOpen(true)}
          >
            {t('policies.createBtn')}
          </Button>
        </div>

        {/* Natural Language Policy Generator */}
        <NaturalLanguagePolicyEditor />

        {/* Configured Policies List */}
        <div className="space-y-4">
          <div className="text-xs font-mono uppercase tracking-wider text-neutral-400">
            Active Policy Rulebooks ({policies.length})
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {policies.map((pol) => {
              const assignedAgents = agents.filter(a => pol.agentIds?.includes(a.id));

              return (
                <div 
                  key={pol.id}
                  className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4 hover:border-white/20 transition-all flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-white text-sm">{pol.name}</div>
                        <p className="text-neutral-400 text-xs mt-1 leading-relaxed">{pol.description}</p>
                      </div>
                      <RiskBadge risk={pol.riskLevel} />
                    </div>

                    <div className="grid grid-cols-3 gap-2 p-3 rounded bg-black/40 border border-white/5 text-[11px] font-mono">
                      <div>
                        <span className="text-neutral-500 block text-[10px]">Daily Cap:</span>
                        <span className="text-white font-medium">${pol.dailyLimit.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 block text-[10px]">Per-Tx Cap:</span>
                        <span className="text-white font-medium">${pol.transactionLimit.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 block text-[10px]">Review Above:</span>
                        <span className="text-amber-300 font-medium">${pol.approvalThreshold.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Allowlist / Blocklist Preview */}
                    <div className="space-y-1.5 text-xs font-mono">
                      <div className="text-[10px] text-neutral-500 uppercase">Authorized Services:</div>
                      <div className="flex flex-wrap gap-1">
                        {pol.allowedServices.map(s => (
                          <span key={s} className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white/[0.04] border border-white/10 text-[10px] text-neutral-300">
                            <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-neutral-500">
                      Applied to: <strong className="text-neutral-300">{assignedAgents.length} Agent(s)</strong>
                    </span>
                    <StatusBadge status={pol.status} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Manual Create Policy Modal */}
        <Modal
          isOpen={createModalOpen}
          onClose={() => setCreateModalOpen(false)}
          title="Create Policy Rulebook"
          subtitle="Define authorization bounds and verification rules"
        >
          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Policy Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Production Data Procurement Policy"
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="Operational purpose of this policy..."
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                  Daily Limit (USD)
                </label>
                <input
                  type="number"
                  step="0.50"
                  value={dailyLimit}
                  onChange={(e) => setDailyLimit(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                  Per-Tx Limit (USD)
                </label>
                <input
                  type="number"
                  step="0.10"
                  value={txLimit}
                  onChange={(e) => setTxLimit(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                Require Human Review Above (USD)
              </label>
              <input
                type="number"
                step="0.05"
                value={approvalThreshold}
                onChange={(e) => setApprovalThreshold(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-black border border-white/15 text-white font-mono focus:outline-none"
              />
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
              <Button variant="ghost" size="md" onClick={() => setCreateModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" size="md" onClick={handleCreate}>
                Commit Policy
              </Button>
            </div>
          </div>
        </Modal>
      </div>
    </AppShell>
  );
}
