'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { StatusBadge, RiskBadge } from '@/components/ui';
import { Search, Filter, ArrowUpRight, CheckCircle2, XCircle } from 'lucide-react';

export default function TransactionsPage() {
  const { transactions, agents, t } = usePayflow();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'APPROVED' | 'BLOCKED'>('ALL');
  const [agentFilter, setAgentFilter] = useState<string>('ALL');

  const filtered = transactions.filter((tx) => {
    const matchesSearch = 
      tx.id.toLowerCase().includes(search.toLowerCase()) ||
      tx.service.toLowerCase().includes(search.toLowerCase()) ||
      tx.purpose.toLowerCase().includes(search.toLowerCase()) ||
      tx.agentName.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || tx.decision === statusFilter;
    const matchesAgent = agentFilter === 'ALL' || tx.agentId === agentFilter;

    return matchesSearch && matchesStatus && matchesAgent;
  });

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider mb-1">
              <span>{t('nav.operations')}</span>
              <span>/</span>
              <span className="text-neutral-300">{t('nav.transactions')}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-semibold text-white tracking-tight">
              {t('transactions.title')}
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
              {t('transactions.subtitle')}
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs text-neutral-400">
            <span>{filtered.length} Recorded Entries</span>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t('transactions.searchPlaceholder')}
              className="w-full pl-9 pr-3 py-1.5 rounded-md bg-surface-1 border border-white/10 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-white/30 font-mono"
            />
          </div>

          <div className="flex items-center gap-2">
            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-2.5 py-1.5 rounded bg-surface-1 border border-white/10 text-xs text-neutral-300 font-mono focus:outline-none"
            >
              <option value="ALL">{t('transactions.allStatuses')}</option>
              <option value="APPROVED">{t('transactions.onlyApproved')}</option>
              <option value="BLOCKED">{t('transactions.onlyBlocked')}</option>
            </select>

            {/* Agent Filter */}
            <select
              value={agentFilter}
              onChange={(e) => setAgentFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded bg-surface-1 border border-white/10 text-xs text-neutral-300 font-mono focus:outline-none"
            >
              <option value="ALL">All Agents</option>
              {agents.map(a => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Transaction Table */}
        <div className="p-5 rounded-md bg-surface-1 border border-white/10">
          <div className="overflow-x-auto -mx-5 px-5">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-neutral-500">
                  <th className="py-2.5 pr-4 font-normal">Tx ID</th>
                  <th className="py-2.5 px-4 font-normal">Timestamp</th>
                  <th className="py-2.5 px-4 font-normal">Agent</th>
                  <th className="py-2.5 px-4 font-normal">Service</th>
                  <th className="py-2.5 px-4 font-normal">Purpose</th>
                  <th className="py-2.5 px-4 font-normal text-right">Amount</th>
                  <th className="py-2.5 px-4 font-normal text-center">Risk</th>
                  <th className="py-2.5 pl-4 font-normal text-right">Decision</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filtered.map((tx) => (
                  <tr 
                    key={tx.id}
                    className="hover:bg-white/[0.02] transition-colors group cursor-pointer"
                    onClick={() => window.location.href = `/transactions/${tx.id}`}
                  >
                    <td className="py-3.5 pr-4 font-mono font-medium text-white group-hover:text-neutral-200">
                      <div className="flex items-center gap-1.5">
                        <span>{tx.id}</span>
                        <ArrowUpRight className="w-3 h-3 text-neutral-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-500 text-[11px]">
                      {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>
                    <td className="py-3.5 px-4 text-white font-medium">
                      {tx.agentName}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-300 text-[11px]">
                      {tx.service}
                    </td>
                    <td className="py-3.5 px-4 text-neutral-400 truncate max-w-xs">
                      {tx.purpose}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-white">
                      ${tx.amount.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <RiskBadge risk={tx.riskLevel} />
                    </td>
                    <td className="py-3.5 pl-4 text-right">
                      <StatusBadge status={tx.decision} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
