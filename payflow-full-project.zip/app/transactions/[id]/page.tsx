'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { AppShell } from '@/components/layout/AppShell';
import { usePayflow } from '@/context/PayflowContext';
import { StatusBadge, RiskBadge, Button } from '@/components/ui';
import { 
  ChevronLeft, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ShieldCheck, 
  FileText, 
  Fingerprint,
  CornerDownRight
} from 'lucide-react';

export default function TransactionDetailPage() {
  const params = useParams();
  const txId = params?.id as string;
  const { transactions, agents, policies } = usePayflow();

  const tx = transactions.find(t => t.id === txId);
  const agent = tx ? agents.find(a => a.id === tx.agentId) : null;
  const policy = tx ? policies.find(p => p.id === tx.policyId) : null;

  if (!tx) {
    return (
      <AppShell>
        <div className="p-8 text-center space-y-4 max-w-md mx-auto my-20">
          <h2 className="text-lg font-semibold text-white">Transaction Not Found</h2>
          <p className="text-xs text-neutral-400">The specified transaction identifier does not exist in the ledger.</p>
          <Link href="/transactions">
            <Button variant="primary" size="md">Return to Transactions</Button>
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="p-6 md:p-8 space-y-6 max-w-5xl mx-auto w-full">
        {/* Navigation Breadcrumbs */}
        <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500 uppercase tracking-wider">
          <Link href="/transactions" className="hover:text-white flex items-center gap-1">
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Transactions</span>
          </Link>
          <span>/</span>
          <span className="text-neutral-300 font-mono">{tx.id}</span>
        </div>

        {/* Top Header Card */}
        <div className="p-6 rounded-md bg-surface-1 border border-white/10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div>
              <div className="text-[11px] font-mono text-neutral-500 uppercase">Transaction Audit Record</div>
              <div className="flex items-center gap-3 mt-1">
                <h1 className="text-2xl font-mono font-medium text-white">{tx.id}</h1>
                <StatusBadge status={tx.decision} />
                <RiskBadge risk={tx.riskLevel} />
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-mono font-semibold text-white">${tx.amount.toFixed(2)} USD</div>
              <div className="text-[11px] font-mono text-neutral-500">
                Environment: <span className="text-neutral-300 uppercase">{tx.environment}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3 rounded bg-black/40 border border-white/5 space-y-1">
              <span className="text-neutral-500 text-[10px] block">Agent Identity:</span>
              <span className="text-white font-medium">{tx.agentName}</span>
            </div>
            <div className="p-3 rounded bg-black/40 border border-white/5 space-y-1">
              <span className="text-neutral-500 text-[10px] block">Service Vendor:</span>
              <span className="text-white font-medium">{tx.service}</span>
            </div>
            <div className="p-3 rounded bg-black/40 border border-white/5 space-y-1">
              <span className="text-neutral-500 text-[10px] block">Settlement Rail:</span>
              <span className="text-neutral-300 font-medium">{tx.paymentMethod}</span>
            </div>
            <div className="p-3 rounded bg-black/40 border border-white/5 space-y-1">
              <span className="text-neutral-500 text-[10px] block">Timestamp:</span>
              <span className="text-neutral-300 font-medium">
                {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          </div>
        </div>

        {/* Two-Column Grid: Request Context & Policy Reasoning */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left: Request Purpose & Metadata */}
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Request Context & Purpose
            </h3>
            <div className="p-3 rounded bg-black/40 border border-white/5 text-xs text-neutral-300 leading-relaxed font-sans">
              {tx.purpose}
            </div>

            <div className="space-y-2 pt-2 text-[11px] font-mono">
              <div className="flex justify-between border-b border-white/5 pb-1 text-neutral-400">
                <span>Associated Policy:</span>
                <span className="text-white">{policy?.name || 'Assigned Policy'}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-1 text-neutral-400">
                <span>Payment Request ID:</span>
                <span className="text-white">{tx.paymentRequestId}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Deterministic Seed:</span>
                <span className="text-white font-mono">sha256-verified</span>
              </div>
            </div>
          </div>

          {/* Right: Policy Decision Explanation */}
          <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Policy Evaluation Decision
            </h3>
            <div className={`p-3 rounded border text-xs font-mono leading-relaxed ${
              tx.decision === 'APPROVED' 
                ? 'bg-emerald-950/20 border-emerald-800/30 text-emerald-200' 
                : 'bg-red-950/20 border-red-800/30 text-red-200'
            }`}>
              <div className="font-semibold mb-1">
                Decision: {tx.decision}
              </div>
              <div>{tx.reason}</div>
            </div>

            <div className="p-3 rounded bg-white/[0.02] border border-white/5 space-y-1 text-xs">
              <div className="text-[11px] font-mono text-neutral-400">Audit Compliance:</div>
              <p className="text-neutral-400 text-[11px] leading-relaxed">
                Evaluated against deterministic constraints: Agent Status, Service Allowlist, Per-Transaction Limit, and Daily Budget Allocations.
              </p>
            </div>
          </div>
        </div>

        {/* Step-by-Step Chronological Audit Trail */}
        <div className="p-5 rounded-md bg-surface-1 border border-white/10 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-white">
              Chronological Audit Trail
            </h3>
            <span className="text-[10px] font-mono text-neutral-500">Immutable Event Log</span>
          </div>

          <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[1px] before:bg-white/15">
            {tx.auditTrail?.map((step, index) => (
              <div key={index} className="relative group text-xs">
                {/* Node icon */}
                <span className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full border flex items-center justify-center text-[9px] font-mono ${
                  step.status === 'passed' 
                    ? 'bg-black border-emerald-500 text-emerald-400' 
                    : 'bg-black border-red-500 text-red-400'
                }`}>
                  {step.status === 'passed' ? '✓' : '×'}
                </span>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="font-medium text-white">{step.action}</div>
                  <span className="text-[10px] font-mono text-neutral-500">{step.time}</span>
                </div>
                <div className="text-neutral-400 text-[11px] font-mono mt-0.5">
                  {step.detail}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
