import { 
  Agent, 
  Policy, 
  PolicyEvaluationResult, 
  PolicyCheckItem, 
  RiskLevel, 
  BudgetImpact 
} from '@/types';

export interface EvaluationInput {
  agent: Agent;
  policy: Policy;
  service: string;
  amount: number;
  purpose: string;
  emergencyStopActive: boolean;
}

export function evaluatePaymentRequest(input: EvaluationInput): PolicyEvaluationResult {
  const { agent, policy, service, amount, purpose, emergencyStopActive } = input;
  const timestamp = new Date().toISOString();
  const checks: PolicyCheckItem[] = [];

  const currentSpend = agent.currentDailySpend;
  const limit = agent.dailyLimit;
  const newSpend = currentSpend + amount;
  const remainingBefore = Math.max(0, limit - currentSpend);
  const remainingAfter = Math.max(0, limit - newSpend);
  const percentUsedBefore = limit > 0 ? Math.min(100, Math.round((currentSpend / limit) * 100)) : 0;
  const percentUsedAfter = limit > 0 ? Math.min(100, Math.round((newSpend / limit) * 100)) : 100;

  const budgetImpact: BudgetImpact = {
    currentSpend,
    limit,
    amount,
    newSpend,
    remainingBefore,
    remainingAfter,
    percentUsedBefore,
    percentUsedAfter,
  };

  // CHECK 0 — EMERGENCY STOP (FAIL CLOSED)
  if (emergencyStopActive) {
    checks.push({
      name: 'Global Emergency Stop',
      passed: false,
      code: 'EMERGENCY_STOP',
      details: 'Global payment emergency stop is active. All automated transactions are blocked.',
    });

    return {
      decision: 'BLOCKED',
      reason: 'Global payment emergency stop is active. All payment processing is halted.',
      riskLevel: 'CRITICAL',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy?.id || 'none',
      timestamp,
    };
  }

  // CHECK 1 — AGENT AUTHORIZATION
  if (!agent) {
    checks.push({
      name: 'Agent Authorization',
      passed: false,
      code: 'AGENT_AUTH',
      details: 'Agent identity could not be verified (Fail closed).',
    });

    return {
      decision: 'BLOCKED',
      reason: 'Agent identity cannot be verified. Authorization denied.',
      riskLevel: 'CRITICAL',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy?.id || 'none',
      timestamp,
    };
  }

  if (agent.status !== 'active') {
    checks.push({
      name: 'Agent Authorization',
      passed: false,
      code: 'AGENT_AUTH',
      details: `Agent "${agent.name}" is currently ${agent.status.toUpperCase()}.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Agent is ${agent.status}. Active status required to initiate payments.`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy?.id || 'none',
      timestamp,
    };
  }

  checks.push({
    name: 'Agent Authorization',
    passed: true,
    code: 'AGENT_AUTH',
    details: `Agent "${agent.name}" is active and authenticated.`,
  });

  // CHECK 2 — POLICY INTEGRITY
  if (!policy || policy.status !== 'active') {
    checks.push({
      name: 'Policy Status',
      passed: false,
      code: 'AGENT_AUTH',
      details: 'Active payment policy required (Fail closed).',
    });

    return {
      decision: 'BLOCKED',
      reason: 'No active policy configured for this agent. Fails closed.',
      riskLevel: 'CRITICAL',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: 'none',
      timestamp,
    };
  }

  // CHECK 3 — SERVICE AUTHORIZATION
  const cleanService = service.trim().toLowerCase();
  const isBlocked = policy.blockedServices?.some(s => s.toLowerCase() === cleanService);
  const isAllowed = policy.allowedServices?.some(s => 
    s.toLowerCase() === cleanService || 
    s.toLowerCase() === 'all' || 
    s.toLowerCase() === 'approved data providers' && ['marketdata pro', 'news api', 'macrodata', 'dataset hub', 'research cloud'].includes(cleanService)
  );

  if (isBlocked) {
    checks.push({
      name: 'Service Authorization',
      passed: false,
      code: 'SERVICE_AUTH',
      details: `Service "${service}" is explicitly on the policy blocklist.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Service "${service}" is explicitly blocked by policy "${policy.name}".`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy.id,
      timestamp,
    };
  }

  if (!isAllowed) {
    checks.push({
      name: 'Service Authorization',
      passed: false,
      code: 'SERVICE_AUTH',
      details: `Service "${service}" is not included in policy allowed services.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Service "${service}" is not authorized under policy "${policy.name}".`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy.id,
      timestamp,
    };
  }

  checks.push({
    name: 'Service Authorization',
    passed: true,
    code: 'SERVICE_AUTH',
    details: `Service "${service}" is explicitly authorized.`,
  });

  // CHECK 4 — TRANSACTION LIMIT
  const txLimit = Math.min(agent.transactionLimit, policy.transactionLimit);
  if (amount > txLimit) {
    checks.push({
      name: 'Transaction Limit',
      passed: false,
      code: 'TX_LIMIT',
      details: `Amount $${amount.toFixed(2)} exceeds per-transaction limit of $${txLimit.toFixed(2)}.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Requested payment of $${amount.toFixed(2)} exceeds the configured per-transaction limit of $${txLimit.toFixed(2)} by $${(amount - txLimit).toFixed(2)}.`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy.id,
      timestamp,
    };
  }

  checks.push({
    name: 'Transaction Limit',
    passed: true,
    code: 'TX_LIMIT',
    details: `Amount $${amount.toFixed(2)} is within transaction limit of $${txLimit.toFixed(2)}.`,
  });

  // CHECK 5 — DAILY BUDGET LIMIT
  const dailyLimit = Math.min(agent.dailyLimit, policy.dailyLimit);
  if (agent.currentDailySpend + amount > dailyLimit) {
    checks.push({
      name: 'Daily Budget',
      passed: false,
      code: 'DAILY_LIMIT',
      details: `Projected daily spend $${(agent.currentDailySpend + amount).toFixed(2)} exceeds daily limit of $${dailyLimit.toFixed(2)}.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Daily budget exceeded. Current spend: $${agent.currentDailySpend.toFixed(2)}, limit: $${dailyLimit.toFixed(2)}, attempted: $${amount.toFixed(2)}.`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy.id,
      timestamp,
    };
  }

  checks.push({
    name: 'Daily Budget',
    passed: true,
    code: 'DAILY_LIMIT',
    details: `Daily spend of $${newSpend.toFixed(2)} remains within $${dailyLimit.toFixed(2)} limit.`,
  });

  // CHECK 6 — MONTHLY BUDGET LIMIT
  const monthlyLimit = Math.min(agent.monthlyLimit, policy.monthlyLimit);
  if (agent.currentMonthlySpend + amount > monthlyLimit) {
    checks.push({
      name: 'Monthly Budget',
      passed: false,
      code: 'MONTHLY_LIMIT',
      details: `Projected monthly spend $${(agent.currentMonthlySpend + amount).toFixed(2)} exceeds monthly limit of $${monthlyLimit.toFixed(2)}.`,
    });

    return {
      decision: 'BLOCKED',
      reason: `Monthly budget exceeded. Projected: $${(agent.currentMonthlySpend + amount).toFixed(2)}, limit: $${monthlyLimit.toFixed(2)}.`,
      riskLevel: 'HIGH',
      checks,
      budgetImpact,
      requiresHumanApproval: false,
      policyId: policy.id,
      timestamp,
    };
  }

  checks.push({
    name: 'Monthly Budget',
    passed: true,
    code: 'MONTHLY_LIMIT',
    details: `Monthly spend remains within $${monthlyLimit.toFixed(2)} limit.`,
  });

  // CHECK 7 — APPROVAL THRESHOLD
  const threshold = policy.approvalThreshold;
  if (amount > threshold) {
    checks.push({
      name: 'Approval Threshold',
      passed: true,
      code: 'APPROVAL_THRESHOLD',
      details: `Amount $${amount.toFixed(2)} exceeds automatic threshold of $${threshold.toFixed(2)}. Human review required.`,
    });

    const risk: RiskLevel = percentUsedAfter > 85 ? 'HIGH' : 'MEDIUM';

    return {
      decision: 'PENDING_APPROVAL',
      reason: `Amount $${amount.toFixed(2)} exceeds autonomous approval threshold ($${threshold.toFixed(2)}). Routed for security confirmation.`,
      riskLevel: risk,
      checks,
      budgetImpact,
      requiresHumanApproval: true,
      policyId: policy.id,
      timestamp,
    };
  }

  checks.push({
    name: 'Approval Threshold',
    passed: true,
    code: 'APPROVAL_THRESHOLD',
    details: `Amount $${amount.toFixed(2)} is within autonomous limit ($${threshold.toFixed(2)}).`,
  });

  // ALL CHECKS PASSED -> AUTO APPROVE
  const finalRisk: RiskLevel = percentUsedAfter > 80 ? 'MEDIUM' : 'LOW';
  return {
    decision: 'APPROVED',
    reason: `All policy rules verified. Agent "${agent.name}" is authorized for "${service}" within daily budget ($${newSpend.toFixed(2)} / $${dailyLimit.toFixed(2)}).`,
    riskLevel: finalRisk,
    checks,
    budgetImpact,
    requiresHumanApproval: false,
    policyId: policy.id,
    timestamp,
  };
}
