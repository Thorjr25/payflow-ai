import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: "#000000",
        surface: {
          DEFAULT: "#080808",
          1: "#080808",
          2: "#0d0d0d",
          3: "#121212",
          4: "#181818",
        },
        border: {
          DEFAULT: "rgba(255, 255, 255, 0.12)",
          soft: "rgba(255, 255, 255, 0.06)",
          strong: "rgba(255, 255, 255, 0.20)",
        },
        silver: {
          DEFAULT: "#d9d9d9",
          muted: "#a0a0a0",
          dark: "#666666",
        },
        status: {
          success: "#dfeee4",
          warning: "#f1e7ce",
          danger: "#f1dddd",
        }
      },
      fontFamily: {
        sans: ["var(--font-inter)", "Inter", "system-ui", "sans-serif"],
        serif: ["var(--font-instrument-serif)", "Instrument Serif", "serif"],
        mono: ["var(--font-mono)", "JetBrains Mono", "monospace"],
      },
      boxShadow: {
        'metal': '0 1px 2px rgba(255, 255, 255, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.25)',
        'metal-glow': '0 0 20px rgba(255, 255, 255, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.8)',
      },
      backgroundImage: {
        'metallic-gradient': 'linear-gradient(180deg, #FFFFFF 0%, #D9D9D9 100%)',
        'metallic-dark': 'linear-gradient(180deg, #1A1A1A 0%, #0D0D0D 100%)',
        'metallic-border': 'linear-gradient(180deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.04) 100%)',
        'subtle-radial': 'radial-gradient(circle at 50% 0%, rgba(255,255,255,0.06) 0%, transparent 70%)',
      },
    },
  },
  plugins: [],
};
export default config;
