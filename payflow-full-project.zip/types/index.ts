export type AgentStatus = 'active' | 'paused' | 'stopped';

export type PolicyStatus = 'active' | 'disabled';

export type PaymentDecision = 
  | 'APPROVED'
  | 'PENDING_APPROVAL'
  | 'REJECTED'
  | 'BLOCKED'
  | 'FAILED';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type Environment = 'simulation' | 'production';

export interface Agent {
  id: string;
  name: string;
  description: string;
  status: AgentStatus;
  dailyLimit: number;
  transactionLimit: number;
  monthlyLimit: number;
  currentDailySpend: number;
  currentMonthlySpend: number;
  policyId: string;
  createdAt: string;
  lastPaymentAt?: string;
  category?: string;
}

export interface Policy {
  id: string;
  name: string;
  description: string;
  agentIds: string[];
  dailyLimit: number;
  transactionLimit: number;
  monthlyLimit: number;
  allowedServices: string[];
  blockedServices: string[];
  approvalThreshold: number;
  riskLevel: RiskLevel;
  status: PolicyStatus;
  createdAt: string;
}

export interface PolicyCheckItem {
  name: string;
  passed: boolean;
  details: string;
  code: 'AGENT_AUTH' | 'SERVICE_AUTH' | 'TX_LIMIT' | 'DAILY_LIMIT' | 'MONTHLY_LIMIT' | 'APPROVAL_THRESHOLD' | 'EMERGENCY_STOP';
}

export interface BudgetImpact {
  currentSpend: number;
  limit: number;
  amount: number;
  newSpend: number;
  remainingBefore: number;
  remainingAfter: number;
  percentUsedBefore: number;
  percentUsedAfter: number;
}

export interface PolicyEvaluationResult {
  decision: PaymentDecision;
  reason: string;
  riskLevel: RiskLevel;
  checks: PolicyCheckItem[];
  budgetImpact: BudgetImpact;
  requiresHumanApproval: boolean;
  policyId: string;
  timestamp: string;
}

export interface PaymentRequest {
  id: string;
  agentId: string;
  service: string;
  amount: number;
  currency: 'USD';
  purpose: string;
  status: PaymentDecision;
  riskLevel: RiskLevel;
  decisionReason: string;
  createdAt: string;
  policyId: string;
  environment: Environment;
  evaluation?: PolicyEvaluationResult;
}

export interface TransactionStep {
  time: string;
  action: string;
  status: 'passed' | 'failed' | 'pending' | 'warning';
  detail: string;
}

export interface Transaction {
  id: string;
  paymentRequestId: string;
  agentId: string;
  agentName: string;
  service: string;
  amount: number;
  currency: 'USD';
  decision: PaymentDecision;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED' | 'BLOCKED' | 'FAILED';
  environment: Environment;
  createdAt: string;
  completedAt?: string;
  policyId: string;
  purpose: string;
  riskLevel: RiskLevel;
  reason: string;
  auditTrail: TransactionStep[];
  paymentMethod: string;
}

export interface AuditEvent {
  id: string;
  transactionId?: string;
  type: 
    | 'AGENT_CREATED'
    | 'AGENT_PAUSED'
    | 'AGENT_RESUMED'
    | 'POLICY_CREATED'
    | 'POLICY_UPDATED'
    | 'POLICY_DELETED'
    | 'PAYMENT_REQUESTED'
    | 'PAYMENT_EVALUATED'
    | 'PAYMENT_APPROVED'
    | 'PAYMENT_REJECTED'
    | 'PAYMENT_BLOCKED'
    | 'EMERGENCY_STOP_ACTIVATED'
    | 'EMERGENCY_STOP_DISABLED'
    | 'APPROVAL_RULE_CREATED'
    | 'ENVIRONMENT_SWITCHED';
  message: string;
  timestamp: string;
  actor: string;
  target?: string;
  result: 'SUCCESS' | 'BLOCKED' | 'FAILED' | 'PENDING';
  metadata?: Record<string, any>;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'approval' | 'warning' | 'security' | 'info';
  link?: string;
}

export interface SpendingPoint {
  date: string;
  approved: number;
  blocked: number;
  pending: number;
  total: number;
}
